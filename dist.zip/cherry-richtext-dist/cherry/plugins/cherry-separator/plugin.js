(function () {
    'use strict';

    var global = tinymce.util.Tools.resolve('tinymce.PluginManager');

    function Plugin () {
      var register = function (editor) {
        editor.ui.registry.addButton('cherry-separator', {
          icon: 'cherry-separator',
          tooltip: '',
          disabled: true,
          onAction: function () {
          }
        });
      };
      global.add('cherry-separator', function (editor) {
        register(editor);
      });
    }

    Plugin();

}());
