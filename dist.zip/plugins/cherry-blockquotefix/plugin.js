(function () {
    'use strict';

    var global = tinymce.util.Tools.resolve('tinymce.PluginManager');

    var inQuoteNode = function (editor) {
      if (!editor || !editor.selection) {
        return false;
      }
      var currentNode = editor.selection.getNode();
      var blockquoteNode = currentNode === null || currentNode === void 0 ? void 0 : currentNode.closest('blockquote');
      if (!currentNode || !currentNode.tagName || !blockquoteNode) {
        return false;
      }
      return true;
    };
    function Plugin () {
      global.add('cherry-blockquotefix', function plugin(editor) {
        editor.on('KeyDown', function (e) {
          if (e.keyCode === 27) {
            if (!inQuoteNode(editor)) {
              return;
            }
            var dom = editor.dom;
            var parentBlock = editor.selection.getSelectedBlocks()[0];
            var containerBlock = parentBlock.parentNode.nodeName == 'BODY' ? dom.getParent(parentBlock, dom.isBlock) : dom.getParent(parentBlock.parentNode, dom.isBlock);
            var newBlock = editor.dom.create('p');
            newBlock.innerHTML = '<br data-mce-bogus="1">';
            dom.insertAfter(newBlock, containerBlock);
            var rng = dom.createRng();
            newBlock.normalize();
            rng.setStart(newBlock, 0);
            rng.setEnd(newBlock, 0);
            editor.selection.setRng(rng);
          }
        });
        var isPElement = function (element) {
          return element && element.tagName && element.tagName.toLowerCase() === 'p';
        };
        var isBrElement = function (element) {
          return element && element.children.length === 1 && element.children[0].tagName.toLowerCase() === 'br';
        };
        var isLastChild = function (parentNode, element) {
          return element && parentNode && parentNode.children.length && parentNode.children[parentNode.children.length - 1] === element;
        };
        var autoEscBlockquote = function (e) {
          if (e.key === 'Enter' && !e.ctrlKey) {
            if (!inQuoteNode(editor)) {
              return;
            }
            var currentNode = editor.selection.getNode();
            var blockquoteNode = currentNode.closest('blockquote');
            var prevNode = currentNode.previousSibling;
            if (isPElement(currentNode) && isPElement(prevNode)) {
              if (isLastChild(blockquoteNode, currentNode) && isBrElement(currentNode) && isBrElement(prevNode)) {
                editor.dom.remove(currentNode);
                editor.dom.remove(prevNode);
                var newLine = editor.dom.create('p', {}, '<br>');
                editor.dom.insertAfter(newLine, blockquoteNode);
                editor.selection.select(newLine, true);
                editor.nodeChanged();
              }
            }
          }
        };
        editor.on('KeyUp', autoEscBlockquote);
      });
    }

    Plugin();

}());
