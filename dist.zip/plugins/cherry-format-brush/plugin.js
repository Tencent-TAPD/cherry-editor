(function () {
    'use strict';

    var global = tinymce.util.Tools.resolve('tinymce.PluginManager');

    function Plugin () {
      global.add('cherry-format-brush', function plugin(editor) {
        var isActive = false;
        var currentStyles = {
          fontStyle: '',
          blocks: []
        };
        function cleanTag(string) {
          return string.replace(/<([^ >]+)[^>]*?>/gi, function (whole, m1) {
            if (/(img|svg|br|hr)/i.test(m1)) {
              return whole;
            }
            if (/\/(li|h1|h2|h3|h4|h5|h6|blockquote|div|p)/i.test(m1)) {
              return '<br>';
            }
            return '';
          });
        }
        function getAllParentNodes(dom, containSelf) {
          if (containSelf === void 0) {
            containSelf = false;
          }
          var ret = containSelf ? [dom] : [];
          for (var parentNode = dom.parentNode; parentNode && parentNode.nodeName != 'BODY'; parentNode = parentNode.parentNode) {
            ret.push(parentNode);
          }
          return ret;
        }
        function testHasParent(parentNodeList, func) {
          return parentNodeList.some(function (item) {
            return func(item);
          });
        }
        function closestParent(parentNodeList, func) {
          return parentNodeList.find(function (item) {
            return func(item);
          });
        }
        function getFontStyle(dom) {
          if (dom.nodeType !== 1) {
            return dom.parentNode.nodeType === 1 ? getFontStyle(dom.parentNode) : '';
          }
          var nodeList = getAllParentNodes(dom, true);
          var belongCode = testHasParent(nodeList, function (item) {
            return item.nodeName === 'PRE';
          }) || testHasParent(nodeList, function (item) {
            return item.nodeName === 'CODE';
          });
          var belongPanel = testHasParent(nodeList, function (item) {
            return /cherry-panel-block/i.test(item.className);
          });
          var needSup = closestParent(nodeList, function (item) {
            return item.nodeName === 'SUP';
          });
          var needSub = closestParent(nodeList, function (item) {
            return item.nodeName === 'SUB';
          });
          var _a = getComputedStyle(dom), font = _a.font, color = _a.color, backgroundColor = _a.backgroundColor, textDecoration = _a.textDecoration, verticalAlign = _a.verticalAlign;
          var finalTextDecoration = textDecoration.match(/(underline|line-through)/g);
          nodeList.map(function (item) {
            var _a, _b, _c;
            if (/(underline|line-through)/.test((_a = item === null || item === void 0 ? void 0 : item.style) === null || _a === void 0 ? void 0 : _a.textDecoration) && ((_b = item.textContent) === null || _b === void 0 ? void 0 : _b.trim()) === ((_c = dom.textContent) === null || _c === void 0 ? void 0 : _c.trim())) {
              var test = item.style.textDecoration.match(/(underline|line-through)/g);
              test.map(function (item) {
                if (finalTextDecoration.indexOf(item) === -1) {
                  finalTextDecoration.push(item);
                }
              });
            }
            if (!testIsBlock(item)) {
              var tmpStyle = getComputedStyle(item);
              if (!/0, 0, 0/.test(tmpStyle.backgroundColor) && /0, 0, 0/.test(backgroundColor)) {
                backgroundColor = tmpStyle.backgroundColor;
              }
              if (!/none/.test(tmpStyle.textDecoration) && /none/.test(textDecoration)) {
                textDecoration = tmpStyle.textDecoration;
              }
              if (!/baseline/.test(tmpStyle.verticalAlign) && /baseline/.test(verticalAlign)) {
                verticalAlign = tmpStyle.verticalAlign;
              }
            }
          });
          var ret = 'font:' + font + ';';
          if (!belongCode) {
            ret = ret + 'color:' + color + ';';
          }
          if (!belongCode && !belongPanel && !/rgba(.*?,\s*0)$/i.test(backgroundColor)) {
            ret = ret + 'background-color:' + backgroundColor + ';';
          }
          if ((finalTextDecoration === null || finalTextDecoration === void 0 ? void 0 : finalTextDecoration.length) > 0) {
            ret = ret + 'text-decoration:' + finalTextDecoration.join(' ') + ';';
          } else {
            ret = ret + 'text-decoration:none;';
          }
          if (needSub) {
            ret = ret + 'vertical-align:sub;';
          } else if (needSup) {
            ret = ret + 'vertical-align:super;';
          } else {
            ret = ret + 'vertical-align:' + verticalAlign + ';';
          }
          return ret;
        }
        function getBlockStyle(dom) {
          var nodeList = getAllParentNodes(dom, true);
          var _a = getComputedStyle(dom), lineHeight = _a.lineHeight, fontSize = _a.fontSize, backgroundColor = _a.backgroundColor, margin = _a.margin, padding = _a.padding, textAlign = _a.textAlign, border = _a.border;
          var belongCode = testHasParent(nodeList, function (item) {
            return item.nodeName === 'PRE';
          }) || testHasParent(nodeList, function (item) {
            return item.nodeName === 'CODE';
          });
          var belongPanel = testHasParent(nodeList, function (item) {
            return /cherry-panel-block/i.test(item.className);
          });
          return 'margin:' + margin + ';padding:' + padding + ';text-align:' + textAlign + ';border:' + border + ';font-size:' + fontSize + ';line-height:' + lineHeight + ';background-color:' + backgroundColor;
        }
        function testIsBlock(node) {
          var testIsBlock = /^(ul|ol|li|h1|h2|h3|h4|h5|h6|blockquote|div|p)$/i;
          return testIsBlock.test(node.nodeName);
        }
        function formatBlockInfo(node) {
          if (!testIsBlock(node)) {
            return [];
          }
          var attrReq = /^<[^ ]+([^>]+?)>[\s\S]*$/;
          var ret = [{
              nodeName: node.nodeName.toLowerCase(),
              attributes: attrReq.test(node.outerHTML) ? node.outerHTML.replace(attrReq, '$1') : '',
              style: getBlockStyle(node)
            }];
          if (/^li$/i.test(node.nodeName)) {
            var nodeList = getAllParentNodes(node, false);
            var closestBlock = closestParent(nodeList, function (item) {
              return /^(ul|ol)$/i.test(item.nodeName);
            });
            if (closestBlock) {
              ret.push({
                nodeName: closestBlock.nodeName.toLowerCase(),
                attributes: attrReq.test(closestBlock.outerHTML) ? closestBlock.outerHTML.replace(attrReq, '$1') : '',
                style: getBlockStyle(closestBlock)
              });
            }
          }
          return ret;
        }
        function uniqueBlockArr(arr) {
          var ret = [];
          for (var i = 0; i < arr.length; i++) {
            ret.push(arr[i]);
            if (!/div/i.test(arr[i].nodeName) && arr[i + 1] && arr[i + 1].nodeName === arr[i].nodeName) {
              i++;
            }
          }
          return ret;
        }
        function getBlocks(dom, checkParent, testText) {
          if (checkParent === void 0) {
            checkParent = false;
          }
          if (testText === void 0) {
            testText = '';
          }
          if (dom.nodeType !== 1) {
            return dom.parentNode ? getBlocks(dom.parentNode, checkParent, testText) : [];
          }
          if (checkParent === false) {
            return formatBlockInfo(dom);
          }
          var nodeList = getAllParentNodes(dom, true);
          var ret = [];
          var stop = false;
          nodeList.map(function (item) {
            var _a;
            if (testText.length > 0) {
              if (testText.trim() === ((_a = item.textContent) === null || _a === void 0 ? void 0 : _a.trim())) {
                ret = ret.concat(formatBlockInfo(item));
              }
            } else {
              if (stop) {
                return false;
              }
              if (/(ol|ul)/i.test(item.nodeName)) {
                stop = true;
              }
              ret = ret.concat(formatBlockInfo(item));
            }
          });
          return uniqueBlockArr(ret);
        }
        function doSetStyle(html, needBlock) {
          if (needBlock === void 0) {
            needBlock = false;
          }
          var text = cleanTag(html);
          if (!needBlock) {
            return text ? '<span style=\'' + currentStyles.fontStyle + '\'>' + text + '</span>' : '';
          }
          if (currentStyles.blocks.length <= 0) {
            return text ? '<p><span style=\'' + currentStyles.fontStyle + '\'>' + text + '</span></p>' : '';
          }
          var blockBefore = '';
          var blockAfter = '';
          var liBefore = '';
          var liAfter = '';
          var liDone = false;
          currentStyles.blocks.map(function (item) {
            if (liDone) {
              blockBefore = '<' + item.nodeName + item.attributes + '>' + blockBefore;
              blockAfter = blockAfter + '</' + item.nodeName + '>';
            } else {
              liBefore = '<' + item.nodeName + item.attributes + '>' + liBefore;
              liAfter = liAfter + '</' + item.nodeName + '>';
            }
            if (/li/i.test(item.nodeName)) {
              liDone = true;
            }
          });
          var final = '';
          var textArr = text.split(/<br[^>]*?>/i);
          textArr.map(function (item) {
            if (item) {
              final += liBefore + '<span style=\'' + currentStyles.fontStyle + '\'>' + item + '</span>' + liAfter;
            }
          });
          return blockBefore.length > 0 ? '' + blockBefore + final + blockAfter : final;
        }
        function saveCurrentStyles() {
          var _a, _b;
          var currentRng = editor.selection.getRng();
          currentStyles.fontStyle = getFontStyle(currentRng.startContainer);
          if (currentRng.startOffset === currentRng.endOffset && currentRng.startContainer === currentRng.endContainer) {
            currentStyles.blocks = getBlocks(currentRng.startContainer, true);
          } else {
            var closestBlockText = (_a = currentRng.commonAncestorContainer.textContent) === null || _a === void 0 ? void 0 : _a.trim();
            var currentSelectText = (_b = currentRng.toString()) === null || _b === void 0 ? void 0 : _b.trim();
            if (closestBlockText !== currentSelectText) {
              currentStyles.blocks = getBlocks(currentRng.startContainer, false);
            } else {
              currentStyles.blocks = getBlocks(currentRng.startContainer, true, currentSelectText);
            }
          }
        }
        function isSelectWholeNode(testBlock) {
          var _a, _b;
          if (testBlock === void 0) {
            testBlock = false;
          }
          var currentRng = editor.selection.getRng();
          var selectedBlocks = editor.selection.getSelectedBlocks();
          var currentSelectText = (_a = currentRng.toString()) === null || _a === void 0 ? void 0 : _a.trim();
          if (selectedBlocks.length > 1) {
            var tmpText_1 = '';
            selectedBlocks.map(function (item) {
              tmpText_1 += item.textContent;
            });
            return currentSelectText === (tmpText_1 === null || tmpText_1 === void 0 ? void 0 : tmpText_1.trim());
          }
          var closestBlockText = (_b = currentRng.commonAncestorContainer.textContent) === null || _b === void 0 ? void 0 : _b.trim();
          if (testBlock) {
            return closestBlockText === currentSelectText && testIsBlock(currentRng.commonAncestorContainer);
          }
          return closestBlockText === currentSelectText;
        }
        function setStyle() {
          if (isActive === false) {
            return true;
          }
          isActive = false;
          var selection = editor.selection;
          var selectedBlocks = selection.getSelectedBlocks();
          var selectedRange = selection.getRng();
          var tdArr = editor.contentDocument.querySelectorAll('td[data-mce-selected="1"]');
          if (tdArr.length > 0) {
            for (var i = 0; i < tdArr.length; i++) {
              tdArr[i].innerHTML = doSetStyle(tdArr[i].innerHTML, true);
            }
          } else if (selectedRange.startOffset === selectedRange.endOffset && selectedRange.startContainer === selectedRange.endContainer) {
            var targetBlock = selectedBlocks[selectedBlocks.length - 1];
            if (/(tr|td|th)/i.test(targetBlock.nodeName)) {
              targetBlock.innerHTML = doSetStyle(targetBlock.innerHTML, true);
            } else {
              targetBlock.outerHTML = doSetStyle(targetBlock.outerHTML, true);
            }
          } else if (currentStyles.blocks.length <= 0 || !isSelectWholeNode(true)) {
            if (selectedRange.startOffset === selectedRange.endOffset && selectedRange.startContainer === selectedRange.endContainer) {
              var closestParentNode = closestParent(getAllParentNodes(selectedRange.commonAncestorContainer, true), function (item) {
                return testIsBlock(item);
              });
              closestParentNode.innerHTML = '<span style=\'' + currentStyles.fontStyle + '\'>' + cleanTag(closestParentNode.innerHTML) + '</span>';
            } else if (selectedBlocks.length <= 1) {
              selection.setContent(doSetStyle(selection.getContent()));
            } else {
              var isBegin_1 = false;
              selectedBlocks.map(function (oneBlock, index) {
                var _a;
                if (index === 0) {
                  isBegin_1 = true;
                }
                if (selectedBlocks[index + 1] && oneBlock === ((_a = selectedBlocks[index + 1]) === null || _a === void 0 ? void 0 : _a.parentNode)) {
                  return true;
                }
                if (isBegin_1 || index === selectedBlocks.length - 1) {
                  var tmpRng = selectedRange.cloneRange();
                  if (isBegin_1) {
                    var endNode = oneBlock.childNodes[oneBlock.childNodes.length - 1];
                    for (; endNode.nodeType !== 3 && endNode.childNodes.length > 0;) {
                      endNode = endNode.childNodes[endNode.childNodes.length - 1];
                    }
                    tmpRng.setEnd(endNode, endNode.textContent.length);
                  } else {
                    var beginNode = oneBlock.childNodes[0];
                    for (; beginNode.nodeType !== 3 && beginNode.childNodes.length > 0;) {
                      beginNode = beginNode.childNodes[0];
                    }
                    tmpRng.setStart(beginNode, 0);
                  }
                  selection.setRng(tmpRng);
                  selection.setContent(doSetStyle(selection.getContent()));
                  isBegin_1 = false;
                } else {
                  oneBlock.innerHTML = doSetStyle(oneBlock.innerHTML);
                }
              });
            }
          } else {
            selection.setContent(doSetStyle(selection.getContent(), true));
          }
          editor.undoManager.add();
          return true;
        }
        editor.ui.registry.addToggleButton('ch-format-brush', {
          icon: 'cherry-brush',
          tooltip: 'Format Brush',
          onAction: function () {
            if (isActive === false) {
              saveCurrentStyles();
            }
            isActive = !isActive;
          },
          onSetup: function (api) {
            api.setActive(isActive);
            editor.on('mouseup', setStyle);
            return function () {
              editor.off('mouseup', setStyle);
            };
          }
        });
      });
    }

    Plugin();

}());
