(function () {
    'use strict';

    var global = tinymce.util.Tools.resolve('tinymce.PluginManager');

    var unfoldIcon = '<svg class=\'foldBtn\' width="16" height="16" style="cursor:pointer" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M8.35357 9.64644C8.15831 9.84171 7.84173 9.84171 7.64647 9.64645L4.85351 6.85356C4.53852 6.53858 4.7616 6 5.20706 6L10.7928 6C11.2383 6 11.4614 6.53857 11.1464 6.85355L8.35357 9.64644Z" fill="#182B50"/>\n</svg>\n';

    var foldIcon = '<svg class=\'foldBtn\' width="16" height="16" style="cursor:pointer"  version="1.1" id="\u56fe\u5c42_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\nviewBox="0 0 850.394 850.394" enable-background="new 0 0 850.394 850.394" xml:space="preserve">\n<path fill="#040000" d="M520.844,411.769L359.193,233.343c-5.552-6.127-14.303-8.208-22.018-5.232\nc-7.715,2.975-12.804,10.392-12.804,18.661l0,356.851c0,8.269,5.089,15.686,12.804,18.66c2.341,0.903,4.778,1.341,7.192,1.341\nc5.54,0,10.959-2.305,14.826-6.572l161.65-178.426C527.749,431.004,527.749,419.389,520.844,411.769z"/>\n</svg>';

    var allowedHeading = {
      'H1': 1,
      'H2': 2,
      'H3': 3,
      'H4': 4,
      'H5': 5,
      'H6': 6
    };
    var MINLEVEL = 100;
    function checkFold(foldTag, checkTag) {
      var _a, _b;
      var checkLevel = (_a = allowedHeading[checkTag]) !== null && _a !== void 0 ? _a : MINLEVEL;
      var foldLevel = (_b = allowedHeading[foldTag]) !== null && _b !== void 0 ? _b : MINLEVEL;
      return foldLevel < checkLevel;
    }
    function toggleFoldIcon(foldState, element) {
      element.removeChild(element.querySelector('.foldBtn'));
      if (foldState == 'unfold') {
        element.innerHTML = unfoldIcon + element.innerHTML;
      } else {
        element.innerHTML = foldIcon + element.innerHTML;
      }
    }
    function addFoldIcon(element) {
      var foldBtn = element.querySelector('.foldBtn');
      if (foldBtn) {
        element.removeChild();
      }
      element.innerHTML = unfoldIcon + element.innerHTML;
    }
    function toggleFold(ele) {
      var addFoldState = ele.classList.contains('fold') ? 'unfold' : 'fold';
      if (addFoldState === 'fold') {
        foldHeading(ele);
      } else {
        unfoldHeading(ele);
      }
    }
    function foldHeading(ele) {
      var currentTagname = ele.tagName;
      var nextEle = ele.nextElementSibling;
      toggleFoldIcon('fold', ele);
      ele.classList.add('fold');
      while (nextEle) {
        if (!checkFold(currentTagname, nextEle.tagName)) {
          break;
        }
        nextEle.style.display = 'none';
        nextEle = nextEle.nextElementSibling;
      }
      ele.classList.remove('unfold');
    }
    function unfoldHeading(ele) {
      var currentTagname = ele.tagName;
      var nextEle = ele.nextElementSibling;
      toggleFoldIcon('unfold', ele);
      ele.classList.add('unfold');
      var appendEle = [];
      while (nextEle) {
        if (!nextEle.style.display) {
          appendEle.push(nextEle.cloneNode(true));
          var tmpNextEle = nextEle.nextElementSibling;
          nextEle.remove();
          nextEle = tmpNextEle;
          continue;
        }
        if (!checkFold(currentTagname, nextEle.tagName)) {
          break;
        }
        nextEle.style.display = '';
        nextEle = nextEle.nextElementSibling;
      }
      appendEle.forEach(function (item) {
        ele.parentElement.insertBefore(item, nextEle);
      });
      ele.classList.remove('fold');
    }

    function Plugin () {
      global.add('cherry-heading-fold', function (editor) {
        setTimeout(function () {
          editor.getDoc().addEventListener('click', function (e) {
            var foldBtn = e.target || null;
            if (foldBtn.classList.contains('foldBtn')) {
              var ele = foldBtn.parentElement;
              toggleFold(ele);
            }
          });
        }, 4000);
        editor.on('change', function (e) {
          var headings = e.target.getDoc().querySelectorAll('h1,h2,h3,h4,h5,h6');
          headings.forEach(function (element) {
            if (!element.classList.contains('foldable')) {
              element.classList.add('foldable');
            }
            if (!element.querySelector('.foldBtn')) {
              addFoldIcon(element);
            }
          });
        });
      });
    }

    Plugin();

}());
