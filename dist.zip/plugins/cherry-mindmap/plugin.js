(function () {
    'use strict';

    var global = tinymce.util.Tools.resolve('tinymce.PluginManager');

    var FULL_SCREEN_ICON = '\n<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M12.9946 3.71637L12.9946 6.51441C12.9946 6.79055 13.2185 7.01441 13.4946 7.01441C13.7708 7.0144 13.9946 6.79055 13.9946 6.5144L13.9946 3.0144C13.9946 2.46212 13.5469 2.0144 12.9946 2.0144H9.49463C9.21849 2.0144 8.99463 2.23826 8.99463 2.5144C8.99463 2.79055 9.21849 3.0144 9.49463 3.0144L12.2824 3.0144L8.93648 6.36035C8.74122 6.55562 8.74122 6.8722 8.93649 7.06746C9.13175 7.26272 9.44833 7.26272 9.64359 7.06745L12.9946 3.71637Z" fill="#182B50"/>\n<path d="M2.01904 12.9883C2.01904 13.5406 2.46676 13.9883 3.01904 13.9883L6.51904 13.9883C6.79519 13.9883 7.01904 13.7644 7.01904 13.4883C7.01904 13.2121 6.79519 12.9883 6.51904 12.9883L3.77304 12.9883L7.09758 9.66386C7.29285 9.46861 7.29286 9.15202 7.0976 8.95676C6.90234 8.76149 6.58576 8.76149 6.39049 8.95674L3.01904 12.3281L3.01904 9.48828C3.01904 9.21214 2.79519 8.98828 2.51904 8.98828C2.2429 8.98828 2.01904 9.21214 2.01904 9.48828V12.9883Z" fill="#182B50"/>\n</svg>\n';

    var EXIT_FULL_SCREEN_ICON = '<svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M10.2224 6.98322L13.0102 6.98322C13.2863 6.98322 13.5102 7.20708 13.5102 7.48322C13.5102 7.75936 13.2863 7.98322 13.0102 7.98322L9.51016 7.98322C8.95788 7.98322 8.51017 7.53551 8.51016 6.98322L8.51015 3.48322C8.51015 3.20708 8.73401 2.98322 9.01015 2.98322C9.28629 2.98322 9.51015 3.20707 9.51015 3.48322L9.51016 6.28122L12.8612 2.93014C13.0564 2.73488 13.373 2.73487 13.5683 2.93013C13.7636 3.1254 13.7636 3.44198 13.5683 3.63724L10.2224 6.98322Z" fill="#182B50"/>\n<path d="M7.51015 10.0001C7.51015 9.44778 7.06244 9.00006 6.51015 9.00006L3.01015 9.00006C2.73401 9.00006 2.51015 9.22392 2.51015 9.50006C2.51015 9.77621 2.73401 10.0001 3.01015 10.0001L5.75616 10.0001L2.43161 13.3245C2.23634 13.5197 2.23634 13.8363 2.4316 14.0316C2.62685 14.2269 2.94344 14.2269 3.1387 14.0316L6.51015 10.6603L6.51015 13.5001C6.51015 13.7762 6.73401 14.0001 7.01015 14.0001C7.28629 14.0001 7.51015 13.7762 7.51015 13.5001L7.51015 10.0001Z" fill="#182B50"/>\n</svg>';

    var CLOSE_ICON = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M4.35355 3.64645C4.15829 3.45118 3.84171 3.45118 3.64645 3.64645C3.45118 3.84171 3.45118 4.15829 3.64645 4.35355L7.29314 8.00024L3.64645 11.6469C3.45118 11.8422 3.45118 12.1588 3.64645 12.354C3.84171 12.5493 4.15829 12.5493 4.35355 12.354L8.00024 8.70735L11.6464 12.3536C11.8417 12.5488 12.1583 12.5488 12.3536 12.3536C12.5488 12.1583 12.5488 11.8417 12.3536 11.6464L8.70735 8.00024L12.3539 4.35374C12.5491 4.15848 12.5491 3.8419 12.3539 3.64663C12.1586 3.45137 11.842 3.45137 11.6467 3.64663L8.00024 7.29314L4.35355 3.64645Z" fill="#182B50"/>\n</svg>\n';

    var CHERRY_MINDMAP_DIALOG = '\n    <div class="cherry-mindmap-dialog__mask">\n    <div class="cherry-mindmap-dialog__content">\n        <div class="cherry-mindmap-dialog__head clearfix">\n            <span class="cherry-mindmap-dialog__head-title">\u63d2\u5165\u601d\u7ef4\u5bfc\u56fe</span>\n            <span class="cherry-mindmap-dialog__head-close j-close-dialog">' + CLOSE_ICON + '</span>\n            <span class="cherry-mindmap-dialog__head-fullscreen font-editor j-set-dialog-size">' + FULL_SCREEN_ICON + '</span>\n        </div>\n        <div class="cherry-mindmap-dialog__body">\n            <div class="cherry-mindmap-dialog__body--loading j-dialog-loading" style="display: block;">\n               <div class="cherry-mindmap-dialog__body--loading_icon strip-loading2"></div>\n            </div>\n            <iframe style="visibility: visible;" allowtransparency="true" id="cherry-mindmap-dialog-iframe" src="CHERRY_MINDMAP_URL" width="100%" frameborder="0" height="100%" loaded="true"></iframe>\n        </div>\n        <div class="cherry-mindmap-dialog__foot">\n        <div class="cherry-mindmap-dialog__foot-btns">\n            <span class="foot-btn foot-btn__ensure j-foot-btn__ensure">\u786e\u5b9a</span>\n            <span class="foot-btn foot-btn__cancel j-close-dialog">\u53d6\u6d88</span>\n        </div>\n        </div>\n    </div>\n    </div>\n';
    var CherryMindmapDialogHelper = function () {
      function CherryMindmapDialogHelper() {
        var _this = this;
        this.target = null;
        this.editor = null;
        this.created = false;
        this.dialogVisble = false;
        this.handlers = {};
        window.addEventListener('message', function (event) {
          if (!event.data || !event.data.eventName || !_this.target) {
            return;
          }
          document.querySelector('.j-cherry-mindmap-dialog .j-dialog-loading').style.display = 'none';
          switch (event.data.eventName) {
          case 'GET_MINDMAP_DATA:SUCCESS':
            _this.onSure(_this.encodeJSON(event.data.value.jsonData), event.data.value.base64Data, event.data.value.imageInfo);
            break;
          }
        }, false);
      }
      CherryMindmapDialogHelper.prototype.init = function (editor) {
        this.editor = editor;
        this.mindmapUrl = editor.getParam('cherry_mindmap_url', '');
      };
      CherryMindmapDialogHelper.prototype.onSure = function (jsonData, base64Data, imageInfo) {
        var _this = this;
        if (imageInfo === void 0) {
          imageInfo = {};
        }
        var self = this;
        var imageTarget = this.target;
        this.beforeInsertJSON(jsonData, function (id, token) {
          if (token === void 0) {
            token = '';
          }
          var imagesUploadHandler = _this.editor.getParam('images_upload_handler', null);
          function success(data) {
            imageTarget.setAttribute('src', data);
            imageTarget.setAttribute('data-mce-src', data);
            imageTarget.setAttribute('data-mindmap-json', id);
            imageTarget.setAttribute('data-mindmap-oldjson', '');
            imageTarget.setAttribute('data-mindmap-oldsrc', '');
            imageTarget.setAttribute('data-mindmap-token', token);
            imageTarget.setAttribute('data-start-key', '');
            if (imageInfo.width) {
              imageTarget.setAttribute('width', '' + imageInfo.width);
            }
            document.querySelector('.j-cherry-mindmap-dialog').style.display = 'none';
            self.target = null;
            self.editor.fire('closeCustomDialog');
          }
          function failed() {
            document.querySelector('.j-cherry-mindmap-dialog').style.display = 'none';
            var mindmapSaveFailed = self.getParam('mindmap_save_failed', null);
            if (typeof mindmapSaveFailed === 'function') {
              mindmapSaveFailed(self.target);
            }
            self.target = null;
            self.editor.fire('closeCustomDialog');
          }
          if (imagesUploadHandler) {
            imagesUploadHandler({
              base64: function () {
                return base64Data;
              }
            }, success, failed);
          } else {
            failed();
          }
        });
      };
      CherryMindmapDialogHelper.prototype.openMindmapDialog = function (item) {
        if (!item) {
          return;
        }
        this.setDialogVisible(item, true, item.getAttribute('data-mindmap-json'), item.getAttribute('data-mindmap-token'));
      };
      CherryMindmapDialogHelper.prototype.setDialogVisible = function (target, val, json, token) {
        var _this = this;
        if (json === void 0) {
          json = '';
        }
        if (token === void 0) {
          token = '';
        }
        var fromInsert = false;
        if (this.target) {
          fromInsert = !!this.target.getAttribute('data-start-key');
          if (!val && fromInsert) {
            this.editor.dom.remove(this.target);
          }
        }
        this.dialogVisble = val;
        if (this.created) {
          this.resetDialogSize();
        }
        if (val) {
          this.target = target;
          this.createIframe(function () {
            if (json && target) {
              _this.beforeParseJSON(json, token, function (originJSON) {
                _this.updateMindmap(originJSON);
              });
            } else {
              _this.updateMindmap(json);
            }
          });
          document.querySelector('.j-cherry-mindmap-dialog').style.display = 'block';
          document.querySelector('.j-cherry-mindmap-dialog .j-dialog-loading').style.display = 'block';
        } else {
          document.querySelector('.j-cherry-mindmap-dialog').style.display = 'none';
          if (!fromInsert && this.target.getAttribute('data-mindmap-oldjson')) {
            this.target.setAttribute('data-mindmap-json', this.target.getAttribute('data-mindmap-oldjson'));
            this.target.setAttribute('src', this.target.getAttribute('data-mindmap-oldsrc'));
            this.target.setAttribute('data-mce-src', this.target.getAttribute('data-mindmap-oldsrc'));
            this.target.setAttribute('data-mindmap-oldjson', '');
            this.target.setAttribute('data-mindmap-oldsrc', '');
          }
          this.target = target;
        }
      };
      CherryMindmapDialogHelper.prototype.insertEmptyImg = function () {
        var key = this.encodeJSON(this.generateRandomKey()).replace(/=/g, '');
        this.editor.insertContent(this.createEmptyMindmaphImg(key));
        var img = this.editor.$('img[data-start-key="' + key + '"]');
        this.openMindmapDialog(img[0]);
      };
      CherryMindmapDialogHelper.prototype.createEmptyMindmaphImg = function (key) {
        var emptyImgPath = this.editor.getParam('mindmap_empty_img');
        var emptyImgJSON = this.editor.getParam('mindmap_empty_json');
        return '<img src="' + emptyImgPath + '" data-start-key="' + key + '" alt="cherry-mindmap" title="\u70b9\u51fb\u56fe\u7247\uFF0C\u8fdb\u5165\u601d\u7ef4\u5bfc\u56fe\u7f16\u8f91" data-control="cherry-mindmap" data-mindmap-json="' + emptyImgJSON + '" data-mindmap-oldjson="' + emptyImgJSON + '">';
      };
      CherryMindmapDialogHelper.prototype.createIframe = function (cb) {
        if (this.created && document.querySelector('.j-cherry-mindmap-dialog')) {
          cb();
          document.querySelector('#cherry-mindmap-dialog-iframe').focus();
          return;
        }
        this.created = true;
        var dialog = document.createElement('div');
        dialog.setAttribute('class', 'cherry-mindmap-dialog j-cherry-mindmap-dialog cherry-mindmap-dialog--normal');
        dialog.style = 'display:none;';
        dialog.innerHTML = CHERRY_MINDMAP_DIALOG.replace('CHERRY_MINDMAP_URL', this.mindmapUrl);
        document.body.appendChild(dialog);
        this.bindEvent();
        setTimeout(function () {
          cb();
          dialog.querySelector('#cherry-mindmap-dialog-iframe').focus();
        }, 3000);
      };
      CherryMindmapDialogHelper.prototype.updateMindmap = function (json) {
        if (!this.dialogVisble) {
          return;
        }
        var ifram = document.getElementById('cherry-mindmap-dialog-iframe').contentWindow;
        ifram.postMessage({
          eventName: 'INIT_MINDMAP',
          value: this.decodeJSON(json)
        }, '*');
        var oldJSON = this.target.getAttribute('data-mindmap-oldjson');
        if (!oldJSON) {
          this.target.setAttribute('data-mindmap-oldjson', this.target.getAttribute('data-mindmap-json'));
          this.target.setAttribute('data-mindmap-oldsrc', this.target.getAttribute('src'));
          this.target.setAttribute('src', this.editor.getParam('mindmap_empty_img'));
          this.target.setAttribute('data-mce-src', this.editor.getParam('mindmap_empty_img'));
        }
      };
      CherryMindmapDialogHelper.prototype.decodeJSON = function (json) {
        if (json && json.trim().indexOf('id:') === 0) {
          return json;
        }
        return json ? decodeURIComponent(escape(window.atob(json))) : null;
      };
      CherryMindmapDialogHelper.prototype.encodeJSON = function (json) {
        if (json && json.trim().indexOf('id:') === 0) {
          return json;
        }
        return window.btoa(unescape(encodeURIComponent(json)));
      };
      CherryMindmapDialogHelper.prototype.bindEvent = function () {
        var _this = this;
        if (!document.querySelector('.j-cherry-mindmap-dialog')) {
          return;
        }
        document.querySelector('.j-cherry-mindmap-dialog .j-foot-btn__ensure').addEventListener('click', function (e) {
          _this.onInsertMindmap(e);
          _this.editor.fire('showDialogTitle');
        });
        document.querySelectorAll('.j-cherry-mindmap-dialog .j-close-dialog').forEach(function (item) {
          item.addEventListener('click', function (e) {
            _this.editor.fire('showDialogTitle');
            _this.setDialogVisible(null, false);
            _this.editor.fire('closeCustomDialog');
          });
        });
        document.querySelector('.j-cherry-mindmap-dialog .j-set-dialog-size').addEventListener('click', function (e) {
          var dialog = document.querySelector('.j-cherry-mindmap-dialog');
          var target = e.target;
          var spanEl = target.closest('.j-set-dialog-size');
          var fullscreenStatus = spanEl.getAttribute('fullscreen');
          var targetClass = target.getAttribute('class');
          var dialogClass = '';
          if (!fullscreenStatus) {
            dialogClass = dialog.getAttribute('class').replace(/cherry-mindmap-dialog--normal/g, 'cherry-mindmap-dialog--fullscreen');
            spanEl.innerHTML = EXIT_FULL_SCREEN_ICON;
            spanEl.setAttribute('fullscreen', '1');
          } else {
            dialogClass = dialog.getAttribute('class').replace(/cherry-mindmap-dialog--fullscreen/g, 'cherry-mindmap-dialog--normal');
            spanEl.innerHTML = FULL_SCREEN_ICON;
            spanEl.setAttribute('fullscreen', '');
          }
          dialog.setAttribute('class', dialogClass);
          target.setAttribute('class', targetClass);
        });
      };
      CherryMindmapDialogHelper.prototype.resetDialogSize = function () {
        var dialog = document.querySelector('.j-cherry-mindmap-dialog');
        var dialogClass = dialog.getAttribute('class');
        if (dialogClass.indexOf('cherry-mindmap-dialog--fullscreen') > -1) {
          dialogClass = dialogClass.replace(/cherry-mindmap-dialog--fullscreen/g, 'cherry-mindmap-dialog--normal');
          dialog.setAttribute('class', dialogClass);
          var fullscreenIcon = document.querySelector('.j-cherry-mindmap-dialog .j-set-dialog-size');
          var fullscreenIconClass = fullscreenIcon.getAttribute('class');
          fullscreenIconClass = fullscreenIconClass.replace(/font-editor-fullscreen-restore/g, 'font-editor-fullscreen');
          fullscreenIcon.setAttribute('class', fullscreenIconClass);
        }
      };
      CherryMindmapDialogHelper.prototype.onInsertMindmap = function (e) {
        var ifram = document.getElementById('cherry-mindmap-dialog-iframe').contentWindow;
        ifram.postMessage({
          eventName: 'GET_MINDMAP_DATA',
          value: ''
        }, '*');
        document.querySelector('.j-cherry-mindmap-dialog .j-dialog-loading').style.display = 'block';
      };
      CherryMindmapDialogHelper.prototype.base64ToFile = function (base64Data, name) {
        var bytes = window.atob(base64Data.split(',')[1]);
        var ab = new ArrayBuffer(bytes.length);
        var ia = new Uint8Array(ab);
        for (var i = 0; i < bytes.length; i++) {
          ia[i] = bytes.charCodeAt(i);
        }
        var file = new Blob([ab], { type: 'image/png' });
        file.lastModifiedDate = new Date();
        file.name = name;
        return file;
      };
      CherryMindmapDialogHelper.prototype.beforeInsertJSON = function (json, cb) {
        var beforeInsertJSON = this.editor.getParam('mindmap_before_insert_json', '');
        if (beforeInsertJSON) {
          beforeInsertJSON(json, function (id, token) {
            if (id) {
              cb('id:' + id, token);
            } else {
              cb(json);
            }
          });
          return;
        }
        cb(json);
      };
      CherryMindmapDialogHelper.prototype.beforeParseJSON = function (json, token, cb) {
        var id = '';
        if (json && json.trim().indexOf('id:') === 0) {
          id = json.trim().replace('id:', '');
        } else {
          cb(json);
          return;
        }
        var beforeParseJSON = this.editor.getParam('mindmap_before_parse_json', '');
        if (beforeParseJSON) {
          beforeParseJSON(id, token, function (orignJSON) {
            if (orignJSON) {
              cb(orignJSON);
            } else {
              cb(json);
            }
          });
          return;
        }
        cb(json);
      };
      CherryMindmapDialogHelper.prototype.generateRandomKey = function () {
        return Math.random().toString(36);
      };
      CherryMindmapDialogHelper.prototype.cacheMindmap = function (json) {
        this.target.setAttribute('data-mindmap-json', this.encodeJSON(json));
        this.editor.fire('keyup', this.editor);
      };
      return CherryMindmapDialogHelper;
    }();
    var mindmapDialogHelper = new CherryMindmapDialogHelper();

    var mindmapIcon = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M13.2227 14H2.79091C2.57273 14 2.38636 13.925 2.23182 13.775C2.07727 13.625 2 13.4409 2 13.2227V2.79091C2 2.57273 2.07727 2.38636 2.23182 2.23182C2.38636 2.07727 2.57273 2 2.79091 2H13.2227C13.4409 2 13.625 2.07727 13.775 2.23182C13.925 2.38636 14 2.57273 14 2.79091V13.2227C14 13.4409 13.925 13.625 13.775 13.775C13.625 13.925 13.4409 14 13.2227 14ZM13.2091 2.79091H2.79091V13.2091H13.2091V2.79091ZM4.67273 4.08636C4.9 4.08636 5.09091 4.16364 5.24545 4.31818C5.4 4.47273 5.47727 4.65909 5.47727 4.87727C5.47727 4.95 5.46818 5.01818 5.45 5.08182L6.59545 6.05C6.85909 5.85909 7.15455 5.76364 7.48182 5.76364C7.64545 5.76364 7.80455 5.78636 7.95909 5.83182L8.62727 4.76818C8.54545 4.63182 8.50455 4.48636 8.50455 4.33182C8.50455 4.11364 8.58182 3.92727 8.73636 3.77273C8.89091 3.61818 9.07955 3.54091 9.30227 3.54091C9.525 3.54091 9.71364 3.61818 9.86818 3.77273C10.0227 3.92727 10.1 4.11364 10.1 4.33182C10.1 4.55 10.0227 4.73864 9.86818 4.89773C9.71364 5.05682 9.52273 5.13636 9.29545 5.13636L9.21364 5.12273L8.53182 6.2C8.74091 6.40909 8.87273 6.65455 8.92727 6.93636L10.6182 6.99091C10.6909 6.85455 10.7886 6.74773 10.9114 6.67045C11.0341 6.59318 11.1727 6.55455 11.3273 6.55455C11.5455 6.55455 11.7318 6.63182 11.8864 6.78636C12.0409 6.94091 12.1182 7.12727 12.1182 7.34545C12.1182 7.56364 12.0409 7.75 11.8864 7.90455C11.7318 8.05909 11.5455 8.13636 11.3273 8.13636C11.1727 8.13636 11.0295 8.09318 10.8977 8.00682C10.7659 7.92045 10.6682 7.80909 10.6045 7.67273L8.91364 7.61818C8.85 7.83636 8.74545 8.02955 8.6 8.19773C8.45455 8.36591 8.27727 8.49545 8.06818 8.58636L8.39545 10.4409C8.64091 10.4773 8.84545 10.5909 9.00909 10.7818C9.17273 10.9727 9.25455 11.1955 9.25455 11.45C9.25455 11.7318 9.15455 11.9727 8.95455 12.1727C8.75455 12.3727 8.51364 12.4727 8.23182 12.4727C7.95 12.4727 7.70909 12.3727 7.50909 12.1727C7.30909 11.9727 7.20909 11.7318 7.20909 11.45C7.20909 11.2591 7.25682 11.0841 7.35227 10.925C7.44773 10.7659 7.57273 10.6455 7.72727 10.5636L7.4 8.70909C7.13636 8.69091 6.89091 8.60909 6.66364 8.46364L5.77727 9.30909C5.80455 9.38182 5.81818 9.46364 5.81818 9.55455C5.81818 9.77273 5.73864 9.95909 5.57955 10.1136C5.42045 10.2682 5.23182 10.3455 5.01364 10.3455C4.79545 10.3455 4.60909 10.2682 4.45455 10.1136C4.3 9.95909 4.22273 9.77045 4.22273 9.54773C4.22273 9.325 4.3 9.13636 4.45455 8.98182C4.60909 8.82727 4.79545 8.75 5.01364 8.75C5.11364 8.75 5.21364 8.76818 5.31364 8.80455L6.2 7.97273C6.07273 7.74545 6.00909 7.5 6.00909 7.23636C6.00909 7 6.05909 6.77727 6.15909 6.56818L5.01364 5.6C4.90455 5.64545 4.79091 5.66818 4.67273 5.66818C4.45455 5.66818 4.26818 5.59091 4.11364 5.43636C3.95909 5.28182 3.88182 5.09545 3.88182 4.87727C3.88182 4.65909 3.95909 4.47273 4.11364 4.31818C4.26818 4.16364 4.45455 4.08636 4.67273 4.08636Z" fill="#2AA3AB"/>\n</svg>\n';
    function Plugin () {
      global.add('cherry-mindmap', function plugin(editor) {
        editor.on('openCustomDialog', function () {
          editor.getBody().setAttribute('contenteditable', 'false');
        });
        editor.on('closeCustomDialog', function () {
          editor.getBody().setAttribute('contenteditable', 'true');
        });
        editor.ui.registry.addIcon('ch-mindmap', mindmapIcon);
        function openMindmapDialog(event) {
          if (event.target.getAttribute('data-control') === 'cherry-mindmap') {
            mindmapDialogHelper.init(editor);
            mindmapDialogHelper.openMindmapDialog(event.target);
            editor.fire('openCustomDialog');
          }
        }
        editor.on('click', openMindmapDialog);
        editor.ui.registry.addButton('ch-mindmap', {
          icon: 'ch-mindmap',
          tooltip: 'CherryMindmap',
          onAction: function () {
            mindmapDialogHelper.init(editor);
            mindmapDialogHelper.insertEmptyImg();
            editor.fire('openCustomDialog');
          },
          onSetup: function () {
            return function () {
            };
          }
        });
      });
    }

    Plugin();

}());
