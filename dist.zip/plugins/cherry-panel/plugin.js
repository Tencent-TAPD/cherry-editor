(function () {
    'use strict';

    var global = tinymce.util.Tools.resolve('tinymce.PluginManager');

    var tipsICON = '\n<svg version="1.1" viewBox="0 0 16 17" xmlns="http://www.w3.org/2000/svg">\n<path d="M9 11.4009C9 11.9532 8.55229 12.4009 8 12.4009C7.44772 12.4009 7 11.9532 7 11.4009V8.40088C7 7.84859 7.44772 7.40088 8 7.40088C8.55228 7.40088 9 7.84859 9 8.40088V11.4009Z" fill="currentColor"/>\n<path d="M8 4.40088C8.55228 4.40088 9 4.84859 9 5.40088C9 5.95316 8.55229 6.40088 8 6.40088C7.44772 6.40088 7 5.95316 7 5.40088C7 4.84859 7.44772 4.40088 8 4.40088Z" fill="currentColor"/>\n<path d="M8 15.4009C11.866 15.4009 15 12.2669 15 8.40088C15 4.53489 11.866 1.40088 8 1.40088C4.13401 1.40088 1 4.53489 1 8.40088C1 12.2669 4.13401 15.4009 8 15.4009ZM8 14.4009C4.68629 14.4009 2 11.7146 2 8.40088C2 5.08717 4.68629 2.40088 8 2.40088C11.3137 2.40088 14 5.08717 14 8.40088C14 11.7146 11.3137 14.4009 8 14.4009Z" fill="currentColor"/>\n</svg>\n';

    var infoICON = '<svg viewBox="0 0 17 17" xmlns="http://www.w3.org/2000/svg">\n<path d="M5.68262 7.01079C5.68262 5.65995 6.82516 4.60596 8.18262 4.60596C9.54007 4.60596 10.6826 5.65995 10.6826 7.01079C10.6826 7.92727 10.15 8.67569 9.41576 9.08638C9.40717 9.09118 9.39717 9.09663 9.38593 9.10275C9.19689 9.20571 8.65879 9.49877 8.68222 10.086C8.69323 10.3619 8.47847 10.5946 8.20255 10.6056C7.92662 10.6166 7.69402 10.4018 7.68301 10.1259C7.65611 9.45144 7.97595 8.96912 8.28476 8.66846C8.43828 8.51899 8.59379 8.4089 8.71457 8.33361C8.82382 8.2655 8.94597 8.20335 8.9276 8.21363C9.39591 7.95168 9.68262 7.51114 9.68262 7.01079C9.68262 6.25762 9.03429 5.60596 8.18262 5.60596C7.33094 5.60596 6.68262 6.25762 6.68262 7.01079C6.68262 7.28693 6.45876 7.51079 6.18262 7.51079C5.90647 7.51079 5.68262 7.28693 5.68262 7.01079Z" fill="currentColor"/>\n<path d="M8.18262 14.5711C4.89652 14.5711 2.23262 11.9072 2.23262 8.62109C2.23262 5.335 4.89652 2.67109 8.18262 2.67109C11.4687 2.67109 14.1326 5.335 14.1326 8.62109C14.1326 11.9072 11.4687 14.5711 8.18262 14.5711ZM8.18262 15.6211C12.0486 15.6211 15.1826 12.4871 15.1826 8.62109C15.1826 4.7551 12.0486 1.62109 8.18262 1.62109C4.31662 1.62109 1.18262 4.7551 1.18262 8.62109C1.18262 12.4871 4.31662 15.6211 8.18262 15.6211Z" fill="currentColor"/>\n<path d="M7.68262 11.6216C7.68262 11.3454 7.90647 11.1216 8.18262 11.1216C8.45876 11.1216 8.68262 11.3454 8.68262 11.6216V12.1212C8.68262 12.3973 8.45876 12.6212 8.18262 12.6212C7.90647 12.6212 7.68262 12.3973 7.68262 12.1212V11.6216Z" fill="currentColor"/>\n</svg>\n';

    var okICON = '<svg viewBox="0 0 17 17" xmlns="http://www.w3.org/2000/svg">\n<path d="M11.5698 7.48411C11.7659 7.28977 11.7674 6.97319 11.5731 6.77701C11.3787 6.58084 11.0622 6.57935 10.866 6.7737L8.18823 9.42646L6.54006 7.77842C6.34479 7.58316 6.02821 7.58317 5.83296 7.77844C5.6377 7.97371 5.63771 8.29029 5.83298 8.48555L7.83305 10.4855C8.02766 10.6801 8.34296 10.6808 8.53848 10.4871L11.5698 7.48411Z" fill="currentColor"/>\n<path d="M15.1826 8.62891C15.1826 12.4949 12.0486 15.6289 8.18262 15.6289C4.31662 15.6289 1.18262 12.4949 1.18262 8.62891C1.18262 4.76291 4.31662 1.62891 8.18262 1.62891C12.0486 1.62891 15.1826 4.76291 15.1826 8.62891ZM14.1326 8.62891C14.1326 5.34281 11.4687 2.67891 8.18262 2.67891C4.89652 2.67891 2.23262 5.34281 2.23262 8.62891C2.23262 11.915 4.89652 14.5789 8.18262 14.5789C11.4687 14.5789 14.1326 11.915 14.1326 8.62891Z" fill="currentColor"/>\n</svg>\n';

    var warningICON = '<svg viewBox="0 0 17 17" xmlns="http://www.w3.org/2000/svg">\n<path d="M9.18262 6.97949C9.18262 6.42721 8.7349 5.97949 8.18262 5.97949C7.63033 5.97949 7.18262 6.42721 7.18262 6.97949V8.97949C7.18262 9.53178 7.63033 9.97949 8.18262 9.97949C8.7349 9.97949 9.18262 9.53178 9.18262 8.97949V6.97949Z" fill="currentColor"/>\n<path d="M9.18262 11.9795C9.18262 12.5318 8.7349 12.9795 8.18262 12.9795C7.63033 12.9795 7.18262 12.5318 7.18262 11.9795C7.18262 11.4272 7.63033 10.9795 8.18262 10.9795C8.7349 10.9795 9.18262 11.4272 9.18262 11.9795Z" fill="currentColor"/>\n<path d="M9.88661 3.35449C9.11681 2.02116 7.19231 2.02116 6.42251 3.35449L1.43304 11.9965C0.663241 13.3298 1.62549 14.9965 3.16509 14.9965H13.144C14.6836 14.9965 15.6459 13.3298 14.8761 11.9965L9.88661 3.35449ZM7.28854 3.85449C7.67344 3.18783 8.63569 3.18783 9.02059 3.85449L14.0101 12.4965C14.395 13.1632 13.9138 13.9965 13.144 13.9965H3.16509C2.39529 13.9965 1.91417 13.1632 2.29907 12.4965L7.28854 3.85449Z" fill="currentColor"/>\n</svg>\n';

    var errorICON = '<svg viewBox="0 0 17 17" xmlns="http://www.w3.org/2000/svg">\n<path d="M5.4316 5.77543C5.62686 5.58017 5.94345 5.58017 6.13871 5.77543L8.28516 7.92188L10.4317 5.77535C10.6269 5.58009 10.9435 5.58009 11.1388 5.77535C11.334 5.97061 11.334 6.2872 11.1388 6.48246L8.99226 8.62898L11.1385 10.7752C11.3338 10.9705 11.3338 11.2871 11.1385 11.4823C10.9433 11.6776 10.6267 11.6776 10.4314 11.4823L8.28516 9.33609L6.13879 11.4825C5.94352 11.6777 5.62694 11.6777 5.43168 11.4825C5.23642 11.2872 5.23642 10.9706 5.43168 10.7754L7.57805 8.62898L5.4316 6.48254C5.23634 6.28727 5.23634 5.97069 5.4316 5.77543Z" fill="currentColor"/>\n<path d="M8.28516 15.6289C12.1511 15.6289 15.2852 12.4949 15.2852 8.62891C15.2852 4.76291 12.1511 1.62891 8.28516 1.62891C4.41916 1.62891 1.28516 4.76291 1.28516 8.62891C1.28516 12.4949 4.41916 15.6289 8.28516 15.6289ZM8.28516 14.6289C4.97145 14.6289 2.28516 11.9426 2.28516 8.62891C2.28516 5.3152 4.97145 2.62891 8.28516 2.62891C11.5989 2.62891 14.2852 5.3152 14.2852 8.62891C14.2852 11.9426 11.5989 14.6289 8.28516 14.6289Z" fill="currentColor"/>\n</svg>\n';

    var deleteICON = '<svg viewBox="0 0 17 17" xmlns="http://www.w3.org/2000/svg">\n<path d="M5.18262 2.27539C5.18262 1.99925 5.40647 1.77539 5.68262 1.77539H10.6826C10.9588 1.77539 11.1826 1.99925 11.1826 2.27539C11.1826 2.55153 10.9588 2.77539 10.6826 2.77539L5.68262 2.77539C5.40647 2.77539 5.18262 2.55153 5.18262 2.27539Z" fill="currentColor"/>\n<path d="M6.68262 7.77539C6.95876 7.77539 7.18262 7.99925 7.18262 8.27539V10.2754C7.18262 10.5515 6.95876 10.7754 6.68262 10.7754C6.40647 10.7754 6.18262 10.5515 6.18262 10.2754V8.27539C6.18262 7.99925 6.40648 7.77539 6.68262 7.77539Z" fill="currentColor"/>\n<path d="M10.1826 8.27539C10.1826 7.99925 9.95876 7.77539 9.68262 7.77539C9.40648 7.77539 9.18262 7.99925 9.18262 8.27539V10.2754C9.18262 10.5515 9.40647 10.7754 9.68262 10.7754C9.95876 10.7754 10.1826 10.5515 10.1826 10.2754V8.27539Z" fill="currentColor"/>\n<path d="M3.16309 4.77539H2.68262C2.40647 4.77539 2.18262 4.55153 2.18262 4.27539C2.18262 3.99925 2.40648 3.77539 2.68262 3.77539L13.6826 3.77539C13.9588 3.77539 14.1826 3.99925 14.1826 4.27539C14.1826 4.55153 13.9588 4.77539 13.6826 4.77539H13.1631V12.7427C13.1631 13.8473 12.2677 14.7427 11.1631 14.7427H5.16309C4.05852 14.7427 3.16309 13.8473 3.16309 12.7427V4.77539ZM4.16309 4.77539V12.7427C4.16309 13.295 4.6108 13.7427 5.16309 13.7427H11.1631C11.7154 13.7427 12.1631 13.295 12.1631 12.7427V4.77539H4.16309Z" fill="currentColor"/>\n</svg>\n';

    function Plugin () {
      global.add('cherry-panel', function plugin(editor) {
        var defaultType = 'tips';
        var defaultBubbleMenu = 'cherry-panel__tips cherry-panel__info cherry-panel__ok cherry-panel__warning cherry-panel__error | cherry-panel__delete';
        var panelList = {
          tips: {
            name: 'tips',
            icon: tipsICON,
            iconName: 'panel-block-icon-tips',
            color: '#3582FB',
            background: '#EBF3FE'
          },
          info: {
            name: 'info',
            icon: infoICON,
            iconName: 'panel-block-icon-info',
            color: '#8091A5',
            background: '#F8F8F8'
          },
          ok: {
            name: 'ok',
            icon: okICON,
            iconName: 'panel-block-icon-ok',
            color: '#56BD5B',
            background: '#EDF9EF'
          },
          warning: {
            name: 'warning',
            icon: warningICON,
            iconName: 'panel-block-icon-warning',
            color: '#FFBF4D',
            background: '#FFEED6'
          },
          error: {
            name: 'error',
            icon: errorICON,
            iconName: 'panel-block-icon-error',
            color: '#F85E5E',
            background: '#FFEFEF'
          },
          delete: {
            name: 'delete',
            icon: deleteICON,
            iconName: 'panel-block-icon-delete',
            color: 'rgb(222, 53, 11)',
            background: 'rgb(255, 235, 230)'
          }
        };
        var getPanelIconShowInIframe = function (type) {
          if (type === void 0) {
            type = defaultType;
          }
          var panel = panelList[type] ? panelList[type] : panelList[defaultType];
          return panel.icon.replace(/<svg version=/g, '<svg style="color:inherit;width:20px;height:20px;" version=');
        };
        var panelTemplate = function (type, html) {
          if (type === void 0) {
            type = defaultType;
          }
          if (html === void 0) {
            html = null;
          }
          var panel = panelList[type] ? panelList[type] : panelList[defaultType];
          var selected = html ? html : editor.selection.getContent();
          var icon = getPanelIconShowInIframe(type);
          return '\n\t\t\t<div contenteditable="false" data-panel-type="' + type + '" class="cherry-panel-block" \n\t\t\t\tstyle="\n\t\t\t\t\tposition: relative;\n\t\t\t\t\tborder-radius: 3px;\n\t\t\t\t\tmargin: 0.75rem 0px 0px;\n\t\t\t\t\tpadding: 8px;\n\t\t\t\t\tword-break: break-word;\n\t\t\t\t\ttransition:all 0.3s ease 0s;\n\t\t\t\t\tbackground-color: ' + panel.background + ';\n\t\t\t\t\tcursor: pointer;\n\t\t\t\t"\n\t\t\t>\n\t\t\t\t<div contenteditable="true" class="cherry-panel-block__content" \n\t\t\t\t\tstyle="\n\t\t\t\t\t\tdisplay:inline-block;\n\t\t\t\t\t\twidth: calc(100% - 35px);\n\t\t\t\t\t\tpadding-left: 35px;\n\t\t\t\t\t\toutline:none;\n\t\t\t\t\t\tposition: relative;\n\t\t\t\t\t"\n\t\t\t\t>\n\t\t\t\t\t<div contenteditable="false" class="cherry-panel-block__left" \n\t\t\t\t\t\tstyle="\n\t\t\t\t\t\t\tdisplay:inline-block;\n\t\t\t\t\t\t\twidth:20px;\n\t\t\t\t\t\t\tvertical-align: top;\n\t\t\t\t\t\t\toutline: none;\n\t\t\t\t\t\t\tcursor: pointer;\n\t\t\t\t\t\t\tposition: absolute;\n\t\t\t\t\t\t\ttop: 0;\n\t\t\t\t\t\t\tleft: 5px;\n\t\t\t\t\t\t"\n\t\t\t\t\t>\n\t\t\t\t\t\t<span contenteditable="false" class="cherry-panel-block__icon" style="width:16px;vertical-align: middle;color:' + panel.color + '">' + icon + '</span>\n\t\t\t\t\t</div>\n\t\t\t\t\t' + (selected ? selected : '<p><br></p>') + '\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t';
        };
        var getCurrentPanelBlock = function () {
          var currentNode = editor.selection.getNode();
          var targetDom = null;
          if (editor.dom.is(currentNode, 'div') && editor.dom.hasClass(currentNode, 'cherry-panel-block')) {
            targetDom = currentNode;
          } else {
            var parentDom = editor.dom.getParent(currentNode, 'div.cherry-panel-block');
            if (parentDom) {
              targetDom = parentDom;
            }
          }
          if (!targetDom || !editor.dom.hasClass(targetDom, 'cherry-panel-block')) {
            return false;
          }
          return targetDom;
        };
        var getCurrentPanelBlockLeft = function () {
          var currentNode = editor.selection.getNode();
          var targetDom = null;
          if (editor.dom.is(currentNode, 'div') && editor.dom.hasClass(currentNode, 'cherry-panel-block__left')) {
            targetDom = currentNode;
          } else {
            var parentDom = editor.dom.getParent(currentNode, 'div.cherry-panel-block__left');
            if (parentDom) {
              targetDom = parentDom;
            }
          }
          if (!targetDom || !editor.dom.hasClass(targetDom, 'cherry-panel-block__left')) {
            return false;
          }
          return targetDom;
        };
        var getCurrentPanelBlockType = function (obj) {
          if (obj === void 0) {
            obj = null;
          }
          if (!obj) {
            obj = getCurrentPanelBlock();
          }
          return editor.dom.getAttrib(obj, 'data-panel-type', defaultType);
        };
        var insert = function (type) {
          if (type === void 0) {
            type = defaultType;
          }
          var isAlreadyPanelBlock = getCurrentPanelBlock();
          if (isAlreadyPanelBlock) {
            return false;
          }
          editor.undoManager.transact(function () {
            editor.insertContent(panelTemplate(type));
            var newNode = getCurrentPanelBlock();
            var targetNode = editor.dom.select('div.cherry-panel-block__content', newNode);
            editor.selection.select(targetNode[0], true);
            editor.nodeChanged();
          });
        };
        var highlight = function (isHighlight) {
          if (isHighlight === void 0) {
            isHighlight = true;
          }
          var targetDom = getCurrentPanelBlock();
          if (editor.dom.hasClass(targetDom, 'cherry-panel-block__highlight')) {
            if (!isHighlight) {
              editor.dom.removeClass(targetDom, 'cherry-panel-block__highlight');
            }
          } else {
            if (isHighlight) {
              editor.dom.addClass(targetDom, 'cherry-panel-block__highlight');
            }
          }
        };
        var change = function (type) {
          if (type === void 0) {
            type = defaultType;
          }
          var panel = panelList[type] ? panelList[type] : panelList[defaultType];
          var targetDom = getCurrentPanelBlock();
          var currentType = getCurrentPanelBlockType(targetDom);
          if (currentType == panel.name) {
            return false;
          }
          editor.dom.setAttrib(targetDom, 'data-panel-type', panel.name);
          editor.dom.setStyle(targetDom, 'background-color', panel.background);
          var spanDoms = editor.dom.select('span.cherry-panel-block__icon', targetDom);
          for (var _i = 0, spanDoms_1 = spanDoms; _i < spanDoms_1.length; _i++) {
            var oneSpanDom = spanDoms_1[_i];
            editor.dom.setStyle(oneSpanDom, 'color', panel.color);
            editor.dom.setHTML(oneSpanDom, getPanelIconShowInIframe(type));
          }
          editor.nodeChanged();
        };
        var remove = function (removeAll) {
          if (removeAll === void 0) {
            removeAll = true;
          }
          var targetDom = getCurrentPanelBlock();
          if (removeAll) {
            editor.dom.remove(targetDom);
          } else {
            var lefts = editor.dom.select('div.cherry-panel-block__left', targetDom);
            for (var _i = 0, lefts_1 = lefts; _i < lefts_1.length; _i++) {
              var left = lefts_1[_i];
              editor.dom.remove(left);
            }
            var contents = editor.dom.select('div.cherry-panel-block__content', targetDom);
            var content = contents[0] ? contents[0] : editor.dom.create('br');
            editor.dom.remove(targetDom);
            editor.insertContent(content.innerHTML);
          }
          editor.nodeChanged();
        };
        var resetCursor = function () {
          editor.dom.select('div.cherry-panel-block__content').forEach(function (dom) {
            if (editor.dom.getAttrib(dom, 'contenteditable') != 'true') {
              editor.dom.setAttrib(dom, 'contenteditable', 'true');
            }
          });
          var selected = getCurrentPanelBlock();
          if (selected === false) {
            return false;
          }
          var isSelectedContent = getCurrentPanelBlockLeft();
          if (isSelectedContent === false) {
            return false;
          }
          editor.selection.select(selected, false);
        };
        var listenEnter = function (e) {
          if (e.key == 'Enter' && !e.ctrlKey) {
            var isPanelBlock_1 = getCurrentPanelBlock();
            if (isPanelBlock_1 === false) {
              return true;
            }
            var currentNode = editor.selection.getNode();
            var prevNode = currentNode.previousSibling;
            var nextNode = currentNode.nextSibling;
            if (currentNode.tagName.toLowerCase() == 'p' && prevNode.tagName.toLowerCase() == 'p') {
              if (/^\n$/.test(currentNode.innerText) && /^\n$/.test(prevNode.innerText)) {
                if (nextNode) {
                  var type = getCurrentPanelBlockType();
                  var allNextNodeHtml = currentNode.outerHTML + nextNode.outerHTML;
                  editor.dom.remove(prevNode);
                  editor.dom.remove(currentNode);
                  while (nextNode.nextSibling) {
                    var tmpNode = nextNode;
                    nextNode = nextNode.nextSibling;
                    editor.dom.remove(tmpNode);
                    allNextNodeHtml += nextNode.outerHTML;
                  }
                  editor.dom.remove(nextNode);
                  var newPanel = panelTemplate(type, allNextNodeHtml);
                  var newLine = editor.dom.create('p', {}, '<br>');
                  editor.dom.insertAfter(newLine, isPanelBlock_1);
                  editor.selection.select(newLine, true);
                  editor.insertContent(newPanel);
                  var newPanelNode = getCurrentPanelBlock();
                  if (newPanelNode) {
                    var firstP = editor.dom.select('div.cherry-panel-block__content p:first', newPanelNode);
                    if (firstP) {
                      editor.selection.select(firstP[0], true);
                    }
                  }
                  editor.nodeChanged();
                } else {
                  editor.dom.remove(currentNode);
                  editor.dom.remove(prevNode);
                  var newLine = editor.dom.create('p', {}, '<br>');
                  editor.dom.insertAfter(newLine, isPanelBlock_1);
                  editor.selection.select(newLine, true);
                  editor.nodeChanged();
                }
              }
            } else if (isBrLine(currentNode) && isLastChild(currentNode) && isBrLine(prevNode)) {
              editor.dom.remove(currentNode);
              editor.dom.remove(prevNode);
              var newLine = editor.dom.create('p', {}, '<br>');
              editor.dom.insertAfter(newLine, isPanelBlock_1);
              editor.selection.select(newLine, true);
              editor.nodeChanged();
            }
          }
        };
        var isPanelBlock = function (dom) {
          if (editor.dom.is(dom, 'div') && editor.dom.hasClass(dom, 'cherry-panel-block')) {
            return true;
          }
          return false;
        };
        var isBrLine = function (element) {
          return element.childNodes.length === 1 && element.childNodes[0].tagName.toLowerCase() === 'br';
        };
        var isLastChild = function (element) {
          if (editor.dom.hasClass(element, 'cherry-panel-block__content')) {
            return true;
          }
          while (!element.nextSibling) {
            element = element.parentNode;
            if (editor.dom.hasClass(element, 'cherry-panel-block__content')) {
              return true;
            }
          }
          return !element.nextSibling;
        };
        editor.on('click', function (e) {
          resetCursor();
        });
        editor.on('keyup', function (e) {
          resetCursor();
          listenEnter(e);
        });
        editor.addCommand('insertCherryPanel', function () {
          insert(defaultType);
        });
        editor.addCommand('changeCherryPanel', function (ui, type) {
          if (type === void 0) {
            type = defaultType;
          }
          change(type);
        });
        editor.addCommand('removeCherryPanel', function () {
          remove(true);
        });
        editor.addCommand('cleanCherryPanel', function () {
          remove(false);
        });
        editor.ui.registry.addToggleButton('ch-panel', {
          icon: panelList[defaultType].iconName,
          tooltip: 'Highlight Block',
          onAction: function (api) {
            if (api.isActive()) {
              editor.execCommand('cleanCherryPanel');
            } else {
              editor.execCommand('insertCherryPanel');
            }
          },
          onSetup: function (api) {
            editor.on('nodeChange', function () {
              var isActive = getCurrentPanelBlock() !== false;
              api.setActive(isActive);
            });
          }
        });
        editor.ui.registry.addContextToolbar('panelblock_toolbar', {
          predicate: function (node) {
            return isPanelBlock(node);
          },
          items: editor.getParam('panelblock_toolbar', defaultBubbleMenu),
          position: 'node',
          scope: 'node'
        });
        Object.keys(panelList).forEach(function (key) {
          if (key != 'delete') {
            editor.ui.registry.addToggleButton('ch-panel__' + key, {
              icon: panelList[key].iconName,
              tooltip: 'Panel Block ' + key,
              onAction: function () {
                editor.execCommand('changeCherryPanel', false, key);
              },
              onSetup: function (api) {
                var type = getCurrentPanelBlockType();
                api.setActive(type == key);
              }
            });
          }
        });
        editor.ui.registry.addToggleButton('ch-panel__delete', {
          icon: panelList.delete.iconName,
          tooltip: 'Panel Block delete',
          onAction: function () {
            editor.execCommand('removeCherryPanel');
          },
          onSetup: function (api) {
            var dom = document.querySelector('.tox-tbtn[aria-label="Panel Block delete"]');
            dom = dom ? dom : document.querySelector('.tox-tbtn[aria-label="\u5220\u9664"]');
            if (!dom) {
              return true;
            }
            dom.onmouseenter = function () {
              highlight(true);
            };
            dom.onmouseleave = function () {
              highlight(false);
            };
            return function (api) {
              dom.onmouseenter = null;
              dom.onmouseleave = null;
            };
          }
        });
      });
    }

    Plugin();

}());
