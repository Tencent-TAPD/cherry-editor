(function () {
    'use strict';

    var global = tinymce.util.Tools.resolve('tinymce.PluginManager');

    var global$1 = tinymce.util.Tools.resolve('tinymce.util.VK');

    var exists = function (xs, pred) {
      for (var i = 0, len = xs.length; i < len; i++) {
        var x = xs[i];
        if (pred(x, i)) {
          return true;
        }
      }
      return false;
    };
    var each = function (xs, f) {
      for (var i = 0, len = xs.length; i < len; i++) {
        var x = xs[i];
        f(x, i);
      }
    };
    var foldl = function (xs, f, acc) {
      each(xs, function (x) {
        acc = f(acc, x);
      });
      return acc;
    };

    var checkRange = function (str, substr, start) {
      return substr === '' || str.length >= substr.length && str.substr(start, start + substr.length) === substr;
    };
    var endsWith = function (str, suffix) {
      return checkRange(str, suffix, str.length - suffix.length);
    };
    var repeat = function (s, count) {
      return count <= 0 ? '' : new Array(count + 1).join(s);
    };

    var global$2 = tinymce.util.Tools.resolve('tinymce.Env');

    var global$3 = tinymce.util.Tools.resolve('tinymce.util.Delay');

    var global$4 = tinymce.util.Tools.resolve('tinymce.util.Promise');

    var firePastePreProcess = function (editor, html, internal, isWordHtml) {
      return editor.fire('PastePreProcess', {
        content: html,
        internal: internal,
        wordContent: isWordHtml
      });
    };
    var firePastePostProcess = function (editor, node, internal, isWordHtml) {
      return editor.fire('PastePostProcess', {
        node: node,
        internal: internal,
        wordContent: isWordHtml
      });
    };

    var global$5 = tinymce.util.Tools.resolve('tinymce.util.Tools');

    var shouldMergeFormats = function (editor) {
      return editor.getParam('paste_merge_formats', true);
    };
    var isSmartPasteEnabled = function (editor) {
      return editor.getParam('smart_paste', true);
    };
    var isSmartPasteALinkEnabled = function (editor) {
      return editor.getParam('smart_paste_a_link', true);
    };
    var isSmartPasteImageLinkEnabled = function (editor) {
      return editor.getParam('smart_paste_image_link', true);
    };
    var getRetainStyleProps = function (editor) {
      return editor.getParam('paste_retain_style_properties');
    };
    var getWordValidElements = function (editor) {
      var defaultValidElements = '-strong/b,-em/i,-u,-span,-p,-ol,-ul,-li,-h1,-h2,-h3,-h4,-h5,-h6,' + '-p/div,-a[href|name],sub,sup,strike,br,del,table[width],tr,' + 'td[colspan|rowspan|width],th[colspan|rowspan|width],thead,tfoot,tbody';
      return editor.getParam('paste_word_valid_elements', defaultValidElements);
    };
    var shouldConvertWordFakeLists = function (editor) {
      return editor.getParam('paste_convert_word_fake_lists', true);
    };
    var shouldUseDefaultFilters = function (editor) {
      return editor.getParam('paste_enable_default_filters', true);
    };
    var getValidate = function (editor) {
      return editor.getParam('validate');
    };
    var getForcedRootBlock = function (editor) {
      return editor.getParam('forced_root_block');
    };
    var getForcedRootBlockAttrs = function (editor) {
      return editor.getParam('forced_root_block_attrs');
    };
    var getTabSpaces = function (editor) {
      return editor.getParam('paste_tab_spaces', 4, 'number');
    };
    var getAllowedImageFileTypes = function (editor) {
      var defaultImageFileTypes = 'jpeg,jpg,jpe,jfi,jif,jfif,png,gif,bmp,webp';
      return global$5.explode(editor.getParam('images_file_types', defaultImageFileTypes, 'string'));
    };

    var internalMimeType = 'x-tinymce/html';
    var internalMark = '<!-- ' + internalMimeType + ' -->';
    var unmark = function (html) {
      return html.replace(internalMark, '');
    };
    var isMarked = function (html) {
      return html.indexOf(internalMark) !== -1;
    };

    var global$6 = tinymce.util.Tools.resolve('tinymce.html.Entities');

    var isPlainText = function (text) {
      return !/<(?:\/?(?!(?:div|p|br|span)>)\w+|(?:(?!(?:span style="white-space:\s?pre;?">)|br\s?\/>))\w+\s[^>]+)>/i.test(text);
    };
    var toBRs = function (text) {
      return text.replace(/\r?\n/g, '<br>');
    };
    var openContainer = function (rootTag, rootAttrs) {
      var key;
      var attrs = [];
      var tag = '<' + rootTag;
      if (typeof rootAttrs === 'object') {
        for (key in rootAttrs) {
          if (rootAttrs.hasOwnProperty(key)) {
            attrs.push(key + '="' + global$6.encodeAllRaw(rootAttrs[key]) + '"');
          }
        }
        if (attrs.length) {
          tag += ' ' + attrs.join(' ');
        }
      }
      return tag + '>';
    };
    var toBlockElements = function (text, rootTag, rootAttrs) {
      var blocks = text.split(/\n/);
      var tagOpen = openContainer(rootTag, rootAttrs);
      var tagClose = '</' + rootTag + '>';
      var paragraphs = global$5.map(blocks, function (p) {
        return p.split(/\n/).join('<br />');
      });
      var stitch = function (p) {
        return tagOpen + p + tagClose;
      };
      return paragraphs.length === 1 ? paragraphs[0] : global$5.map(paragraphs, stitch).join('');
    };
    var convert = function (text, rootTag, rootAttrs) {
      return rootTag ? toBlockElements(text, rootTag === true ? 'p' : rootTag, rootAttrs) : toBRs(text);
    };

    var global$7 = tinymce.util.Tools.resolve('tinymce.html.DomParser');

    var global$8 = tinymce.util.Tools.resolve('tinymce.html.Serializer');

    var __assign = function () {
      __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p))
              t[p] = s[p];
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };

    var nbsp = '\xA0';

    var global$9 = tinymce.util.Tools.resolve('tinymce.html.Node');

    var global$a = tinymce.util.Tools.resolve('tinymce.html.Schema');

    function filter(content, items) {
      global$5.each(items, function (v) {
        if (v.constructor === RegExp) {
          content = content.replace(v, '');
        } else {
          content = content.replace(v[0], v[1]);
        }
      });
      return content;
    }
    function innerText(html) {
      var schema = global$a();
      var domParser = global$7({}, schema);
      var text = '';
      var shortEndedElements = schema.getShortEndedElements();
      var ignoreElements = global$5.makeMap('script noscript style textarea video audio iframe object', ' ');
      var blockElements = schema.getBlockElements();
      function walk(node) {
        var name = node.name, currentNode = node;
        if (name === 'br') {
          text += '\n';
          return;
        }
        if (name === 'wbr') {
          return;
        }
        if (shortEndedElements[name]) {
          text += ' ';
        }
        if (ignoreElements[name]) {
          text += ' ';
          return;
        }
        if (node.type === 3) {
          text += node.value;
        }
        if (!node.shortEnded) {
          if (node = node.firstChild) {
            do {
              walk(node);
            } while (node = node.next);
          }
        }
        if (blockElements[name] && currentNode.next) {
          text += '\n';
          if (name === 'p') {
            text += '\n';
          }
        }
      }
      html = filter(html, [/<!\[[^\]]+\]>/g]);
      walk(domParser.parse(html));
      return text;
    }
    function trimHtml(html) {
      function trimSpaces(all, s1, s2) {
        if (!s1 && !s2) {
          return ' ';
        }
        return nbsp;
      }
      html = filter(html, [
        /^[\s\S]*<body[^>]*>\s*|\s*<\/body[^>]*>[\s\S]*$/ig,
        /<!--StartFragment-->|<!--EndFragment-->/g,
        [
          /( ?)<span class="Apple-converted-space">\u00a0<\/span>( ?)/g,
          trimSpaces
        ],
        /<br class="Apple-interchange-newline">/g,
        /<br>$/i
      ]);
      return html;
    }

    function isWordContent(content) {
      return /<font face="Times New Roman"|class="?Mso|style="[^"]*\bmso-|style='[^']*\bmso-|w:WordDocument/i.test(content) || /class="OutlineElement/.test(content) || /id="?docs\-internal\-guid\-/.test(content);
    }
    function isNumericList(text) {
      var found;
      var patterns = [
        /^[IVXLMCD]{1,2}\.[ \u00a0]/,
        /^[ivxlmcd]{1,2}\.[ \u00a0]/,
        /^[a-z]{1,2}[\.\)][ \u00a0]/,
        /^[A-Z]{1,2}[\.\)][ \u00a0]/,
        /^[0-9]+\.[ \u00a0]/,
        /^[\u3007\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d]+\.[ \u00a0]/,
        /^[\u58f1\u5f10\u53c2\u56db\u4f0d\u516d\u4e03\u516b\u4e5d\u62fe]+\.[ \u00a0]/
      ];
      text = text.replace(/^[\u00a0 ]+/, '');
      global$5.each(patterns, function (pattern) {
        if (pattern.test(text)) {
          found = true;
          return false;
        }
      });
      return found;
    }
    function isBulletList(text) {
      return /^[\s\u00a0]*[\u2022\u00b7\u00a7\u25CF\u25cb\u25a0]\s*/.test(text);
    }
    function isCheckList(text) {
      return /^[\s\u00a0]*[\uf06e]\s*/.test(text);
    }
    function convertFakeListsToProperLists(node) {
      var currentListNode, prevListNode, lastLevel = 1;
      function getText(node) {
        var txt = '';
        if (node.type === 3) {
          return node.value;
        }
        if (node = node.firstChild) {
          do {
            txt += getText(node);
          } while (node = node.next);
        }
        return txt;
      }
      function trimListStart(node, regExp) {
        if (node.type === 3) {
          if (regExp.test(node.value)) {
            node.value = node.value.replace(regExp, '');
            return false;
          }
        }
        if (node = node.firstChild) {
          do {
            if (!trimListStart(node, regExp)) {
              return false;
            }
          } while (node = node.next);
        }
        return true;
      }
      function removeIgnoredNodes(node) {
        if (node._listIgnore) {
          node.remove();
          return;
        }
        if (node = node.firstChild) {
          do {
            removeIgnoredNodes(node);
          } while (node = node.next);
        }
      }
      function convertParagraphToLi(paragraphNode, listName, start, isCheckList) {
        var level = paragraphNode._listLevel || lastLevel;
        if (level !== lastLevel) {
          if (level < lastLevel) {
            if (currentListNode) {
              currentListNode = currentListNode.parent.parent;
            }
          } else {
            prevListNode = currentListNode;
            currentListNode = null;
          }
        }
        if (!currentListNode || currentListNode.name !== listName) {
          prevListNode = prevListNode || currentListNode;
          currentListNode = new global$9(listName, 1);
          if (isCheckList) {
            currentListNode.attr('class', 'tox-checklist');
          }
          if (start > 1) {
            currentListNode.attr('start', '' + start);
          }
          paragraphNode.wrap(currentListNode);
        } else {
          currentListNode.append(paragraphNode);
        }
        paragraphNode.name = 'li';
        if (level > lastLevel && prevListNode) {
          prevListNode.lastChild.append(currentListNode);
        }
        lastLevel = level;
        removeIgnoredNodes(paragraphNode);
        trimListStart(paragraphNode, /^\u00a0+/);
        trimListStart(paragraphNode, /^\s*([\u2022\u00b7\u00a7\u25CF\u25cb\u25a0]|\w+\.)/);
        trimListStart(paragraphNode, /^\u00a0+/);
        trimListStart(paragraphNode, /^\uf06e+/);
      }
      var elements = [];
      var child = node.firstChild;
      while (typeof child !== 'undefined' && child !== null) {
        elements.push(child);
        child = child.walk();
        if (child !== null) {
          while (typeof child !== 'undefined' && child.parent !== node) {
            child = child.walk();
          }
        }
      }
      for (var i = 0; i < elements.length; i++) {
        node = elements[i];
        if (node.name === 'p' && node.firstChild) {
          var nodeText = getText(node);
          if (isBulletList(nodeText)) {
            convertParagraphToLi(node, 'ul');
            continue;
          }
          if (isCheckList(nodeText)) {
            convertParagraphToLi(node, 'ul', 1, true);
            continue;
          }
          if (isNumericList(nodeText)) {
            var matches = /([0-9]+)\./.exec(nodeText);
            var start = 1;
            if (matches) {
              start = parseInt(matches[1], 10);
            }
            convertParagraphToLi(node, 'ol', start);
            continue;
          }
          if (node._listLevel) {
            convertParagraphToLi(node, 'ul', 1);
            continue;
          }
          currentListNode = null;
        } else {
          prevListNode = currentListNode;
          currentListNode = null;
        }
      }
    }
    function filterStyles(editor, validStyles, node, styleValue) {
      var outputStyles = {}, matches;
      var styles = editor.dom.parseStyle(styleValue);
      global$5.each(styles, function (value, name) {
        switch (name) {
        case 'mso-list':
          matches = /\w+ \w+([0-9]+)/i.exec(styleValue);
          if (matches) {
            node._listLevel = parseInt(matches[1], 10);
          }
          if (/Ignore/i.test(value) && node.firstChild) {
            node._listIgnore = true;
            node.firstChild._listIgnore = true;
          }
          break;
        case 'horiz-align':
          name = 'text-align';
          break;
        case 'vert-align':
          name = 'vertical-align';
          break;
        case 'font-color':
        case 'mso-foreground':
          name = 'color';
          break;
        case 'mso-background':
        case 'mso-highlight':
          name = 'background';
          break;
        case 'font-weight':
        case 'font-style':
          if (value !== 'normal') {
            outputStyles[name] = value;
          }
          return;
        case 'mso-element':
          if (/^(comment|comment-list)$/i.test(value)) {
            node.remove();
            return;
          }
          break;
        }
        if (name.indexOf('mso-comment') === 0) {
          node.remove();
          return;
        }
        if (name.indexOf('mso-') === 0) {
          return;
        }
        if (getRetainStyleProps(editor) === 'all' || validStyles && validStyles[name]) {
          outputStyles[name] = value;
        }
      });
      if (/(bold)/i.test(outputStyles['font-weight'])) {
        delete outputStyles['font-weight'];
        node.wrap(new global$9('b', 1));
      }
      if (/(italic)/i.test(outputStyles['font-style'])) {
        delete outputStyles['font-style'];
        node.wrap(new global$9('i', 1));
      }
      outputStyles = editor.dom.serializeStyle(__assign(__assign({}, styles), outputStyles), node.name);
      if (outputStyles) {
        return outputStyles;
      }
      return null;
    }
    var filterWordContent = function (editor, content) {
      var validStyles;
      var retainStyleProperties = getRetainStyleProps(editor);
      if (retainStyleProperties) {
        validStyles = global$5.makeMap(retainStyleProperties.split(/[, ]/));
      }
      content = filter(content, [
        /<br class="?Apple-interchange-newline"?>/gi,
        /<b[^>]+id="?docs-internal-[^>]*>/gi,
        /<!--[\s\S]+?-->/gi,
        /<(!|script[^>]*>.*?<\/script(?=[>\s])|\/?(\?xml(:\w+)?|img|meta|link|style|\w:\w+)(?=[\s\/>]))[^>]*>/gi,
        [
          /<(\/?)s>/gi,
          '<$1strike>'
        ],
        [
          /&nbsp;/gi,
          nbsp
        ],
        [
          /<span\s+style\s*=\s*"\s*mso-spacerun\s*:\s*yes\s*;?\s*"\s*>([\s\u00a0]*)<\/span>/gi,
          function (str, spaces) {
            return spaces.length > 0 ? spaces.replace(/./, ' ').slice(Math.floor(spaces.length / 2)).split('').join(nbsp) : '';
          }
        ]
      ]);
      var validElements = getWordValidElements(editor);
      var schema = global$a({
        valid_elements: validElements,
        valid_children: '-li[p]'
      });
      global$5.each(schema.elements, function (rule) {
        if (!rule.attributes.class) {
          rule.attributes.class = {};
          rule.attributesOrder.push('class');
        }
        if (!rule.attributes.style) {
          rule.attributes.style = {};
          rule.attributesOrder.push('style');
        }
      });
      var domParser = global$7({}, schema);
      domParser.addAttributeFilter('style', function (nodes) {
        var i = nodes.length, node;
        while (i--) {
          node = nodes[i];
          node.attr('style', filterStyles(editor, validStyles, node, node.attr('style')));
          if (node.name === 'span' && node.parent && !node.attributes.length) {
            node.unwrap();
          }
        }
      });
      domParser.addAttributeFilter('class', function (nodes) {
        var i = nodes.length, node, className;
        while (i--) {
          node = nodes[i];
          className = node.attr('class');
          if (/^(MsoCommentReference|MsoCommentText|msoDel)$/i.test(className)) {
            node.remove();
          }
          node.attr('class', null);
        }
      });
      domParser.addNodeFilter('del', function (nodes) {
        var i = nodes.length;
        while (i--) {
          nodes[i].remove();
        }
      });
      domParser.addNodeFilter('a', function (nodes) {
        var i = nodes.length, node, href, name;
        while (i--) {
          node = nodes[i];
          href = node.attr('href');
          name = node.attr('name');
          if (href && href.indexOf('#_msocom_') !== -1) {
            node.remove();
            continue;
          }
          if (href && href.indexOf('file://') === 0) {
            href = href.split('#')[1];
            if (href) {
              href = '#' + href;
            }
          }
          if (!href && !name) {
            node.unwrap();
          } else {
            if (name && !/^_?(?:toc|edn|ftn)/i.test(name)) {
              node.unwrap();
              continue;
            }
            node.attr({
              href: href,
              name: name
            });
          }
        }
      });
      var rootNode = domParser.parse(content);
      if (shouldConvertWordFakeLists(editor)) {
        convertFakeListsToProperLists(rootNode);
      }
      content = global$8({ validate: getValidate(editor) }, schema).serialize(rootNode);
      return content;
    };
    var preProcess = function (editor, content) {
      return shouldUseDefaultFilters(editor) ? filterWordContent(editor, content) : content;
    };

    var preProcess$1 = function (editor, html) {
      var parser = global$7({}, editor.schema);
      parser.addNodeFilter('meta', function (nodes) {
        global$5.each(nodes, function (node) {
          node.remove();
        });
      });
      parser.addNodeFilter('#text', function (nodes) {
        global$5.each(nodes, function (node) {
          if (node.parent.name === 'style') {
            node.value = node.value.replace(/text-indent/g, 'original-text-indent');
          }
          return node;
        });
      });
      var fragment = parser.parse(html, {
        forced_root_block: false,
        isRootContent: true
      });
      return global$8({ validate: getValidate(editor) }, editor.schema).serialize(fragment);
    };
    var processResult = function (content, cancelled) {
      return {
        content: content,
        cancelled: cancelled
      };
    };
    var postProcessFilter = function (editor, html, internal, isWordHtml) {
      var tempBody = editor.dom.create('div', { style: 'display:none' }, html);
      var postProcessArgs = firePastePostProcess(editor, tempBody, internal, isWordHtml);
      return processResult(postProcessArgs.node.innerHTML, postProcessArgs.isDefaultPrevented());
    };
    var filterContent = function (editor, content, internal, isWordHtml) {
      var preProcessArgs = firePastePreProcess(editor, content, internal, isWordHtml);
      var filteredContent = preProcess$1(editor, preProcessArgs.content);
      if (editor.hasEventListeners('PastePostProcess') && !preProcessArgs.isDefaultPrevented()) {
        return postProcessFilter(editor, filteredContent, internal, isWordHtml);
      } else {
        return processResult(filteredContent, preProcessArgs.isDefaultPrevented());
      }
    };
    var process = function (editor, html, internal) {
      var isWordHtml = isWordContent(html);
      var content = isWordHtml ? preProcess(editor, html) : html;
      var alignCenterClass = (content.match(/^\.\w+\s*\{[^}]*text-align:center;/img) || []).map(function (res) {
        return res.match(/^\.(\w+)\s*\{/)[1];
      });
      var alignRightClass = (content.match(/^\.\w+\s*\{[^}]*text-align:right;/img) || []).map(function (res) {
        return res.match(/^\.(\w+)\s*\{/)[1];
      });
      content = content.replace(/class=\w+[^>]*style='/ig, function (res) {
        var className = res.match(/class=(\w+)/i)[1];
        if (alignCenterClass.indexOf(className) !== -1) {
          return res + 'text-align:center;';
        }
        if (alignRightClass.indexOf(className) !== -1) {
          return res + 'text-align:right;';
        }
        return res;
      });
      var borderClass = (content.match(/^\.\w+\s*\{[^}]*font-weight:700;/img) || []).map(function (res) {
        return res.match(/^\.(\w+)\s*\{/)[1];
      });
      content = content.replace(/font-weight:700;/ig, '').replace(/class=(\w+)[^>]*>[^<]*</ig, function (res) {
        var className = res.match(/class=(\w+)/i)[1];
        if (borderClass.indexOf(className) !== -1) {
          return res.replace(/>([^<]*)</, '><strong>$1</strong><');
        }
        return res;
      });
      content = content.replace(/:\s*[\d.]+pt/ig, function (res) {
        var ptVal = res.match(/:\s*([\d.]+)pt/i)[1];
        return ':' + (Number(ptVal) * 1.33).toFixed(2) + 'px';
      });
      return filterContent(editor, content, internal, isWordHtml);
    };

    var pasteHtml = function (editor, html) {
      editor.insertContent(html, {
        merge: shouldMergeFormats(editor),
        paste: true
      });
      return true;
    };
    var isAbsoluteUrl = function (url) {
      return /^https?:\/\/[\w\?\-\/+=.&%@~#]+$/i.test(url);
    };
    var isImageUrl = function (editor, url) {
      return isAbsoluteUrl(url) && exists(getAllowedImageFileTypes(editor), function (type) {
        return endsWith(url, '.' + type);
      });
    };
    var createImage = function (editor, url, pasteHtmlFn) {
      editor.undoManager.extra(function () {
        pasteHtmlFn(editor, url);
      }, function () {
        editor.insertContent('<img src="' + url + '">');
      });
      return true;
    };
    var createLink = function (editor, url, pasteHtmlFn) {
      editor.undoManager.extra(function () {
        pasteHtmlFn(editor, url);
      }, function () {
        editor.execCommand('mceInsertLink', false, url);
      });
      return true;
    };
    var linkSelection = function (editor, html, pasteHtmlFn) {
      return editor.selection.isCollapsed() === false && isAbsoluteUrl(html) ? createLink(editor, html, pasteHtmlFn) : false;
    };
    var insertImage = function (editor, html, pasteHtmlFn) {
      return isImageUrl(editor, html) ? createImage(editor, html, pasteHtmlFn) : false;
    };
    var smartInsertContent = function (editor, html) {
      var smartActions = [];
      if (isSmartPasteALinkEnabled(editor)) {
        smartActions.push(linkSelection);
      }
      if (isSmartPasteImageLinkEnabled(editor)) {
        smartActions.push(insertImage);
      }
      smartActions.push(pasteHtml);
      global$5.each(smartActions, function (action) {
        return action(editor, html, pasteHtml) !== true;
      });
    };
    var insertContent = function (editor, html, pasteAsText) {
      if (pasteAsText || isSmartPasteEnabled(editor) === false) {
        pasteHtml(editor, html);
      } else {
        smartInsertContent(editor, html);
      }
    };

    var isCollapsibleWhitespace = function (c) {
      return ' \f\t\x0B'.indexOf(c) !== -1;
    };
    var isNewLineChar = function (c) {
      return c === '\n' || c === '\r';
    };
    var isNewline = function (text, idx) {
      return idx < text.length && idx >= 0 ? isNewLineChar(text[idx]) : false;
    };
    var normalizeWhitespace = function (editor, text) {
      var tabSpace = repeat(' ', getTabSpaces(editor));
      var normalizedText = text.replace(/\t/g, tabSpace);
      var result = foldl(normalizedText, function (acc, c) {
        if (isCollapsibleWhitespace(c) || c === nbsp) {
          if (acc.pcIsSpace || acc.str === '' || acc.str.length === normalizedText.length - 1 || isNewline(normalizedText, acc.str.length + 1)) {
            return {
              pcIsSpace: false,
              str: acc.str + nbsp
            };
          } else {
            return {
              pcIsSpace: true,
              str: acc.str + ' '
            };
          }
        } else {
          return {
            pcIsSpace: isNewLineChar(c),
            str: acc.str + c
          };
        }
      }, {
        pcIsSpace: false,
        str: ''
      });
      return result.str;
    };

    var doPaste = function (editor, content, internal, pasteAsText) {
      var args = process(editor, content, internal);
      if (args.cancelled === false) {
        insertContent(editor, args.content, pasteAsText);
      }
    };
    var pasteHtml$1 = function (editor, html, internalFlag) {
      var internal = internalFlag ? internalFlag : isMarked(html);
      doPaste(editor, unmark(html), internal, false);
    };
    var pasteText = function (editor, text) {
      var encodedText = editor.dom.encode(text).replace(/\r\n/g, '\n');
      var normalizedText = normalizeWhitespace(editor, encodedText);
      var html = convert(normalizedText, getForcedRootBlock(editor), getForcedRootBlockAttrs(editor));
      doPaste(editor, html, false, true);
    };
    var getDataTransferItems = function (dataTransfer) {
      var items = {};
      var mceInternalUrlPrefix = 'data:text/mce-internal,';
      if (dataTransfer) {
        if (dataTransfer.getData) {
          var legacyText = dataTransfer.getData('Text');
          if (legacyText && legacyText.length > 0) {
            if (legacyText.indexOf(mceInternalUrlPrefix) === -1) {
              items['text/plain'] = legacyText;
            }
          }
        }
        if (dataTransfer.types) {
          for (var i = 0; i < dataTransfer.types.length; i++) {
            var contentType = dataTransfer.types[i];
            try {
              items[contentType] = dataTransfer.getData(contentType);
            } catch (ex) {
              items[contentType] = '';
            }
          }
        }
      }
      return items;
    };
    var getClipboardContent = function (editor, clipboardEvent) {
      return getDataTransferItems(clipboardEvent.clipboardData || editor.getDoc().dataTransfer);
    };
    var hasContentType = function (clipboardContent, mimeType) {
      return mimeType in clipboardContent && clipboardContent[mimeType].length > 0;
    };

    var DropDownIcon = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M4.13666 6.20258C4.42956 5.90969 4.90443 5.90969 5.19732 6.20258L8.00033 9.00558L10.8033 6.20258C11.0962 5.90969 11.5711 5.90969 11.864 6.20258C12.1569 6.49547 12.1569 6.97035 11.864 7.26324L8.53066 10.5966C8.39 10.7372 8.19924 10.8162 8.00033 10.8162C7.80141 10.8162 7.61065 10.7372 7.47 10.5966L4.13666 7.26324C3.84377 6.97035 3.84377 6.49547 4.13666 6.20258Z" fill="#182B50"/>\n</svg>\n';

    var PasteIcon = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M6 1C5.44772 1 5 1.44772 5 2C3.89543 2 3 2.89543 3 4V11C3 12.1046 3.89543 13 5 13H7.02246C7.02246 14.1046 7.91789 15 9.02246 15H11.3787C11.9091 15 12.4178 14.7893 12.7929 14.4142L14.4167 12.7904C14.7898 12.4173 15.0004 11.9119 15.0025 11.3843L15.0163 8.00817C15.0208 6.90042 14.1241 6 13.0163 6H13V4C13 2.89543 12.1046 2 11 2C11 1.44772 10.5523 1 10 1H6ZM12 6H9.02246C7.91789 6 7.02246 6.89543 7.02246 8V12H5C4.44772 12 4 11.5523 4 11V4C4 3.44772 4.44772 3 5 3C5 3.55228 5.44772 4 6 4H10C10.5523 4 11 3.55228 11 3C11.5523 3 12 3.44772 12 4V6ZM10 3H6V2H10V3ZM9.02246 14C8.47018 14 8.02246 13.5523 8.02246 13V8C8.02246 7.44772 8.47018 7 9.02246 7H13.0163C13.5702 7 14.0186 7.45021 14.0163 8.00408L14.0041 11L14 11H12C11.4477 11 11 11.4477 11 12V14H9.02246ZM12 12H13.7841C13.7609 12.029 13.7361 12.0568 13.7096 12.0833L12.0858 13.7071C12.0585 13.7343 12.0299 13.7599 12 13.7836V12Z" fill="#152646"/>\n</svg>\n';

    function getLastElement(node) {
      var last = node;
      while (last.lastElementChild) {
        last = last.lastElementChild;
      }
      return last;
    }
    var CherryPasteManager = function () {
      function CherryPasteManager(editor) {
        var _this = this;
        this.editor = null;
        this.clipboardContent = null;
        this.pasteInfo = null;
        this._controller = null;
        this.isActive = false;
        this.lastPasteType = '';
        this.isTypeChangeEvent = false;
        this._timer = null;
        this.bmBeforePaste = null;
        this.contentBeforePaste = null;
        this.editor = editor;
        editor.execCommand('addFloatingItemConfig', false, {
          name: 'paste-controller',
          id: 'tapd-paste-controller',
          getContent: function () {
            return _this.controller;
          },
          customLayoutMap: {
            north: 'southeast',
            south: 'southeast',
            east: 'southeast',
            west: 'southeast',
            northeast: 'southeast',
            southeast: 'southeast',
            northwest: 'southeast',
            southwest: 'southeast'
          }
        });
      }
      CherryPasteManager.prototype.onPrePaste = function () {
        this.reset();
        this.bmBeforePaste = this.editor.selection.getBookmark(2, true);
        this.contentBeforePaste = this.editor.getBody().innerHTML;
      };
      CherryPasteManager.prototype.onPostPaste = function (evt) {
        this.pasteInfo = evt;
        this.needShowController = true;
        var content = evt.node.innerHTML;
        var isPlainText$1 = isPlainText(content);
        this.isPlainText = isPlainText$1;
        var isTable = evt.node.lastChild.tagName === 'TABLE' || evt.node.firstChild.tagName === 'TABLE';
        if (!this.isChangeTypePaste && (isPlainText$1 || isTable)) {
          this.needShowController = false;
        }
        if (!this.needShowController) {
          return;
        }
        var lastElm = getLastElement(evt.node);
        var node = evt.node;
        var editor = this.editor;
        var startMarker = editor.dom.get(CherryPasteManager.StartMarkerID);
        var endMarker = editor.dom.get(CherryPasteManager.EndMarkerID);
        if (!startMarker) {
          startMarker = editor.dom.create('span', {
            'id': CherryPasteManager.StartMarkerID,
            'data-mce-bookmark': '1'
          });
        }
        if (!endMarker) {
          endMarker = editor.dom.create('span', {
            'id': CherryPasteManager.EndMarkerID,
            'data-mce-bookmark': '1'
          });
        }
        if (node.firstChild.nodeType === 1) {
          node = node.firstChild;
        }
        node.insertBefore(startMarker, node.firstChild);
        lastElm.appendChild(endMarker);
      };
      CherryPasteManager.prototype.onPaste = function (clipboardContent) {
        if (clipboardContent) {
          this.clipboardContent = clipboardContent;
        }
      };
      CherryPasteManager.prototype.onInsertPasteContent = function () {
        if (!this.needShowController) {
          return;
        }
        this.isChangeTypePaste = false;
        this.afterInsertContent();
        this.showController();
      };
      CherryPasteManager.prototype.reset = function () {
        this.hideController();
      };
      CherryPasteManager.prototype.changePasteType = function (type) {
        if (!this.clipboardContent) {
          return;
        }
        this.isTypeChangeEvent = true;
        this.hideController();
        if (!this.selectPasteContent()) {
          this.editor.undoManager.add();
          this.editor.getBody().innerHTML = this.contentBeforePaste;
          this.editor.selection.moveToBookmark(this.bmBeforePaste);
        }
        this.isChangeTypePaste = true;
        if (type === 'plain') {
          this.insertClipboardContent(true);
        } else if (type === 'html') {
          this.insertClipboardContent(false);
        }
        this.showController();
      };
      CherryPasteManager.prototype.insertClipboardContent = function (plainTextMode) {
        var _a = this, clipboardContent = _a.clipboardContent, editor = _a.editor;
        var internal = this.pasteInfo.internal;
        var content;
        if (hasContentType(clipboardContent, 'text/html')) {
          content = clipboardContent['text/html'];
        } else {
          var tempDom = document.createElement('div');
          tempDom.innerHTML = clipboardContent['text/plain'];
          content = tempDom.innerHTML;
        }
        content = trimHtml(content);
        if (plainTextMode) {
          if (hasContentType(clipboardContent, 'text/plain') && this.isPlainText) {
            content = clipboardContent['text/plain'];
          } else {
            content = innerText(content);
          }
        }
        if (plainTextMode) {
          pasteText(editor, content);
        } else {
          pasteHtml$1(editor, content, internal);
        }
        this.afterInsertContent();
      };
      CherryPasteManager.prototype.initPasteControllerDom = function () {
        if (!window.document.querySelector('#paste-controller')) {
          window.document.documentElement.appendChild(this.controller);
        }
      };
      CherryPasteManager.prototype.hideController = function () {
        this.editor.execCommand('hideFloatingItem', false, { id: 'tapd-paste-controller' });
        var startMarker = this.editor.dom.get(CherryPasteManager.StartMarkerID);
        var endMarker = this.editor.dom.get(CherryPasteManager.EndMarkerID);
        if (startMarker) {
          startMarker.remove();
        }
        if (endMarker) {
          endMarker.remove();
        }
        this.isActive = false;
        clearTimeout(this._timer);
      };
      CherryPasteManager.prototype._hideIfNecessary = function () {
        var _this = this;
        if (this.isActive) {
          this._timer = setTimeout(function () {
            if (!_this.editor.dom.get(CherryPasteManager.EndMarkerID)) {
              _this.hideController();
            }
            _this._hideIfNecessary();
          }, 500);
        }
      };
      CherryPasteManager.prototype.showController = function () {
        var target = this.editor.dom.get(CherryPasteManager.EndMarkerID);
        if (!target) {
          this.hideController();
          return;
        }
        this.isActive = true;
        this._hideIfNecessary();
        this.editor.execCommand('showFloatingItem', false, {
          id: 'tapd-paste-controller',
          target: target
        });
      };
      CherryPasteManager.prototype.selectPasteContent = function () {
        var dom = this.editor.dom;
        var startMarker = dom.get(CherryPasteManager.StartMarkerID);
        var endMarker = dom.get(CherryPasteManager.EndMarkerID);
        if (startMarker && endMarker) {
          var newRng = this.editor.dom.createRng();
          newRng.setStart(startMarker, 0);
          newRng.setEnd(endMarker, 0);
          this.editor.selection.setRng(newRng);
          return true;
        }
        return false;
      };
      CherryPasteManager.prototype.afterInsertContent = function () {
      };
      Object.defineProperty(CherryPasteManager.prototype, 'controller', {
        get: function () {
          var _this = this;
          if (!!this._controller) {
            return this._controller;
          }
          var parser = new DOMParser();
          var dropDownSvg = parser.parseFromString(DropDownIcon, 'image/svg+xml').querySelector('svg');
          var pasteSvg = parser.parseFromString(PasteIcon, 'image/svg+xml').querySelector('svg');
          var _controller = document.createElement('div');
          _controller.id = 'paste-controller-area';
          var _iconWrapper = document.createElement('div');
          _iconWrapper.classList.add('action-wrapper');
          var _icon = document.createElement('div');
          _icon.classList.add('action-list');
          _icon.innerHTML = '<span id="point_paste"></span><span id="point_drop_down" style="padding-left: 4px;"></span>';
          _icon.querySelector('#point_paste').appendChild(pasteSvg);
          _icon.querySelector('#point_drop_down').appendChild(dropDownSvg);
          var _actionsListPanel = parser.parseFromString('<div class="paste-controller-panel"><div class="action__html">\u4fdd\u7559\u6e90\u683c\u5f0f</div><div class="action__plain">\u4ec5\u4fdd\u7559\u6587\u672c</div></div>', 'text/html').querySelector('.paste-controller-panel');
          var btnConvert2html = _actionsListPanel.querySelector('.action__html');
          var btnConvert2plain = _actionsListPanel.querySelector('.action__plain');
          btnConvert2html.addEventListener('mousedown', function () {
            _iconWrapper.classList.remove('active');
            _iconWrapper.classList.remove('hover');
            _this.changePasteType('html');
          });
          btnConvert2plain.addEventListener('mousedown', function () {
            _iconWrapper.classList.remove('active');
            _iconWrapper.classList.remove('hover');
            _this.changePasteType('plain');
          });
          _iconWrapper.addEventListener('click', function () {
            if (_iconWrapper.classList.contains('active')) {
              _iconWrapper.classList.remove('active');
              _iconWrapper.classList.remove('hover');
            } else {
              _this.selectPasteContent();
              _iconWrapper.classList.add('active');
            }
          });
          this.editor.getDoc().addEventListener('click', function (e) {
            if (e.target !== _iconWrapper && !_iconWrapper.contains(e.target)) {
              _iconWrapper.classList.remove('active');
            }
          });
          var leaveTimer = null;
          var mouseEnterHandler = function (e) {
            clearTimeout(leaveTimer);
            _iconWrapper.classList.add('hover');
            _actionsListPanel.focus();
          };
          var mouseLeaveHandler = function (e) {
            if (_iconWrapper.contains(e.relatedTarget)) {
              return;
            }
            leaveTimer = setTimeout(function () {
              _iconWrapper.classList.remove('hover');
            }, 500);
          };
          _iconWrapper.addEventListener('mouseenter', function (e) {
            mouseEnterHandler();
          });
          _iconWrapper.addEventListener('mouseleave', function (e) {
            mouseLeaveHandler(e);
          });
          _actionsListPanel.addEventListener('mouseenter', function (e) {
            mouseEnterHandler();
          });
          _actionsListPanel.addEventListener('mouseleave', function (e) {
            mouseLeaveHandler(e);
          });
          _iconWrapper.appendChild(_icon);
          _controller.appendChild(_iconWrapper);
          _controller.appendChild(_actionsListPanel);
          this._controller = _controller;
          return this._controller;
        },
        set: function (value) {
          this._controller = value;
        },
        enumerable: false,
        configurable: true
      });
      CherryPasteManager.StartMarkerID = 'paste-marker-start';
      CherryPasteManager.EndMarkerID = 'paste-marker-end';
      return CherryPasteManager;
    }();

    var _this = undefined;
    var debounce = function (func, wait) {
      var timeout;
      return function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        clearTimeout(timeout);
        timeout = setTimeout(function () {
          func.apply(_this, args);
        }, wait);
      };
    };
    function Plugin () {
      global.add('cherry-paste', function plugin(editor) {
        editor.ui.registry.addFloating('paste-controller', {
          position: 'node',
          scope: 'node'
        });
        editor.on('init', function () {
          editor.once('focus', function () {
            var pasteManager = new CherryPasteManager(editor);
            editor.on('PastePreProcess', function (evt) {
              pasteManager.onPrePaste();
            });
            editor.on('PastePostProcess', function (evt) {
              pasteManager.onPostPaste(evt);
            });
            editor.on('paste', function (evt) {
              var clipboardContent = getClipboardContent(editor, evt);
              pasteManager.onPaste(clipboardContent);
            });
            editor.on('ExecCommand', function (e) {
              var _a;
              if (e.command === 'mceInsertContent' && ((_a = e.value) === null || _a === void 0 ? void 0 : _a.paste)) {
                pasteManager.onInsertPasteContent();
              }
            });
            var isKeyboardPasteEvent = function (e) {
              return global$1.metaKeyPressed(e) && e.keyCode === 86 || e.shiftKey && e.keyCode === 45;
            };
            var ignoreCodes = [
              'Meta',
              'Control',
              'Alt',
              'Command',
              'Shift'
            ];
            ignoreCodes = ignoreCodes.reduce(function (pre, item) {
              return pre.concat([
                item + 'Left',
                item + 'Right'
              ]);
            }, ignoreCodes);
            ignoreCodes = ignoreCodes.concat([
              'CapsLock',
              'Tab'
            ]);
            var keydownCallback = debounce(function (e) {
              if (!isKeyboardPasteEvent(e) && !e.isDefaultPrevented() && ignoreCodes.indexOf(e.code) === -1) {
                pasteManager.hideController();
              }
            }, 300);
            editor.on('keydown', keydownCallback);
            var changeCallback = debounce(function (e) {
              var _a, _b, _c, _d, _e;
              if (((_a = e.originalEvent) === null || _a === void 0 ? void 0 : _a.command) === 'mceInsertContent' || e.inputType === 'insertFromPaste' || ((_b = e.originalEvent) === null || _b === void 0 ? void 0 : _b.type) === 'blur' || ((_c = e.originalEvent) === null || _c === void 0 ? void 0 : _c.command) === 'mceInsertContent' && ((_d = e.originalEvent.value) === null || _d === void 0 ? void 0 : _d.paste) || ((_e = e.originalEvent) === null || _e === void 0 ? void 0 : _e.command) === 'showFloatingItem') {
                return;
              }
              pasteManager.hideController();
            }, 300);
            editor.on('change input Undo', changeCallback);
            editor.on('Remove', function () {
              pasteManager.hideController();
            });
          });
        });
      });
    }

    Plugin();

}());
